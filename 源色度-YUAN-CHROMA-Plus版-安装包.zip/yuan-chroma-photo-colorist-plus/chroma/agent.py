"""Local two-stage handoff shared by host Agents and optional vision adapters."""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import tempfile

from .agent_schema import MODEL_SCHEMA, REVIEW_SCHEMA, BUNDLE_SCHEMA, validate_model_contract, validate_review_contract
from .io import load_photo, pixel_hash, sha256_file, write_json
from .jobs import _inside, _load_job, _read, _review, _preview, _preflight, prepare_job, run_job
from .workflow import load_style_model
from .style_audit import audit_model, audit_job

RESOURCES=Path(__file__).with_name('agent_resources')


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def _editable(root):
    if (root/'execution.lock.json').exists() or (root/'run.json').exists() or (root/'results').exists():
        raise ValueError('Execution already started; preserve this job and prepare a new job for revised analysis.')


@contextmanager
def _writing(root):
    path=_inside(root,'.agent-write.lock')
    try:
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError as exc:
        raise ValueError('Another Agent submission is active. If interrupted, preserve the job and prepare a new one.') from exc
    try:
        os.close(fd)
        yield
    finally:
        path.unlink(missing_ok=True)


def _snapshot(root,job):
    # Previews are evidence: reconstruct and compare them with the bound originals.
    paths=[(job['reference']['image'],job['reference']['preview'],job['reference']['sha256'])]
    paths.extend((r['image'],r['preview'],r['image_sha256']) for r in job['sources'])
    hashes={}
    with tempfile.TemporaryDirectory(prefix='.chroma-evidence-') as td:
        for index,(rel,preview,digest) in enumerate(paths):
            image=_inside(root,rel)
            if sha256_file(image)!=digest:
                raise ValueError('Job image changed: '+rel)
            photo=load_photo(image)
            if index:
                row=job['sources'][index-1]
                if pixel_hash(photo)!=row['pixel_sha256'] or photo.orientation!=row['orientation'] or photo.metadata['stored_size']!=row['stored_size']:
                    raise ValueError('Source identity/size/orientation mismatch')
            expected=Path(td)/'expected.png';_preview(photo,expected)
            actual=_inside(root,preview)
            if sha256_file(expected)!=sha256_file(actual):
                raise ValueError('Preview differs from bound original: '+preview)
            hashes[rel]=digest;hashes[preview]=sha256_file(actual)
    model_path=_inside(root,job['style_model'])
    if model_path.exists():
        model=load_style_model(model_path,_inside(root,job['reference']['image']))
        validate_model_contract(model)
        hashes[job['style_model']]=sha256_file(model_path)
        frozen=job.get('style_freeze')
        if frozen is not None:
            actual={'model_sha256':sha256_file(model_path),'reference_sha256':job['reference']['sha256'],
                    'strength':job['strength'],'renderer_sha256':sha256_file(Path(__file__).with_name('style_renderer.py'))}
            if actual!=frozen:
                raise ValueError('Frozen style changed')
    return hashes


def build_request(directory):
    root,job=_load_job(directory);_editable(root)
    if (root/'.agent-write.lock').exists():
        raise ValueError('Agent submission is active')
    evidence=_snapshot(root,job)
    has_style=_inside(root,job['style_model']).exists()
    stage='source_adaptation' if has_style else 'reference_style'
    schema=deepcopy(BUNDLE_SCHEMA)
    schema['properties']['sources']['minItems']=len(job['sources']) if has_style else 0
    schema['properties']['sources']['maxItems']=len(job['sources']) if has_style else 0
    schema['properties']['style_model']={'type':'null'} if has_style else MODEL_SCHEMA
    request={'schema_version':1,'workflow':'chroma-agent-handoff-v1','stage':stage,
        'job_sha256':sha256_file(root/'job.json'),
        'renderer_sha256':sha256_file(Path(__file__).with_name('style_renderer.py')),
        'evidence_sha256':evidence,'reference_sha256':job['reference']['sha256'],
        'strength':job['strength'], 'response_schema':schema,
        'instructions':(RESOURCES/('source.txt' if has_style else 'style.txt')).read_text(encoding='utf-8'),
        'images':[{'role':'reference','preview':job['reference']['preview']}],
        'style_model':_read(_inside(root,job['style_model'])) if has_style else None,
        'sources':[{'id':r['id'],'source_pixel_sha256':r['pixel_sha256'],'preview':r['preview'],
                    'stored_size':r['stored_size'],'orientation':r['orientation']} for r in job['sources']] if has_style else [],
        'limits':['Statistics are auxiliary, not a style analysis.','No physical lighting reconstruction.',
                  'Technical QA does not mean user aesthetic acceptance.']}
    if has_style:
        request['images']=[{'role':'original','id':r['id'],'preview':r['preview']} for r in job['sources']]
        request['operator_audit']=audit_model(request['style_model'])
    request['request_sha256']=_digest(request)
    return root,request


def agent_request(directory):
    root,request=build_request(directory)
    path=_inside(root,'agent-request.json')
    if path.exists() and _read(path)!=request:
        raise ValueError('Existing Agent request changed. Prepare a new job to preserve analysis evidence.')
    if not path.exists():
        write_json(path,request)
    return {'job_directory':str(root),'stage':request['stage'],'request':str(path),
        'request_sha256':request['request_sha256'],
        'images':[str(_inside(root,image['preview'])) for image in request['images']],
        'next':'Agent views these actual images and submits one bound JSON response with agent-submit.'}


def agent_start(inputs,reference,directory,style_model=None,strength=1,freeze_style=False):
    prepare_job(inputs,reference,directory,style_model,strength,freeze_style)
    return agent_request(directory)


def submit_analysis(directory,analysis,render=False):
    root,job=_load_job(directory)
    path=_inside(root,'agent-request.json')
    if not path.exists():
        raise ValueError('Run agent-request before submitting analysis')
    request=_read(path)
    _,actual=build_request(root)
    if request!=actual:
        raise ValueError('Agent evidence changed after request; prepare a new job')
    data=_read(analysis) if isinstance(analysis,(str,Path)) else deepcopy(analysis)
    if not isinstance(data,dict) or set(data)!={'schema_version','request_sha256','style_model','sources'} or type(data['schema_version']) is not int or data['schema_version']!=1:
        raise ValueError('Unsupported Agent analysis envelope')
    if data['request_sha256']!=request['request_sha256']:
        raise ValueError('Agent analysis belongs to another request')
    model=data['style_model'];sources=data['sources']
    if not isinstance(sources,list):
        raise ValueError('Sources must be an array')
    style_stage=request['stage']=='reference_style'
    if style_stage:
        if sources or model is None:
            raise ValueError('Analyze reference style first, without source adaptations in this stage')
        validate_model_contract(model)
        if model['reference_sha256']!=job['reference']['sha256']:
            raise ValueError('Style analysis belongs to another reference')
    else:
        if model is not None:
            raise ValueError('Style is fixed during source adaptation; do not rewrite it')
        expected={r['id']:r for r in job['sources']}
        if len(sources)!=len(expected) or any(not isinstance(s,dict) or set(s)!={'id','review'} or not isinstance(s['id'],str) for s in sources):
            raise ValueError('Analyze every source exactly once')
        ids=[s['id'] for s in sources]
        if len(set(ids))!=len(ids) or set(ids)!=set(expected):
            raise ValueError('Duplicate, missing or unknown source analysis')
        for item in sources:
            validate_review_contract(item['review'])
            if item['review']['source_pixel_sha256']!=expected[item['id']]['pixel_sha256']:
                raise ValueError('Source review belongs to another original')
    # Validate in an isolated copy before changing any model/review file. Commit
    # with byte backups; receipts retain the exact submitted bundle for audit.
    receipt_name='agent-style.receipt.json' if style_stage else 'agent-sources.receipt.json'
    receipt=_inside(root,receipt_name)
    if receipt.exists():
        raise ValueError('Stage already submitted; prepare a new job for revisions')
    with _writing(root):
        _editable(root)
        if sha256_file(root/'job.json')!=request['job_sha256'] or sha256_file(Path(__file__).with_name('style_renderer.py'))!=request['renderer_sha256']:
            raise ValueError('Job/renderer changed during submission')
        # Recheck the bound images after acquiring the write guard.
        if _snapshot(root,job)!=request['evidence_sha256']:
            raise ValueError('Images/model changed during submission')
        changes={job['style_model']:model} if style_stage else {expected[s['id']]['review']:s['review'] for s in sources}
        targets=[_inside(root,rel) for rel in changes]
        protected=[_inside(root,rel) for rel in request['evidence_sha256'] if rel!=job['style_model']]
        protected.extend([root/'job.json',path,receipt,root/'agent-style.receipt.json'])
        if len(set(targets))!=len(targets) or any(t==p or (t.exists() and p.exists() and t.samefile(p)) for t in targets for p in protected):
            raise ValueError('Analysis destination aliases an input/evidence file')
        backups={};created=[]
        try:
            with tempfile.TemporaryDirectory(prefix='.chroma-handoff-') as td:
                stage=Path(td)
                for rel,value in changes.items():
                    p=_inside(root,rel)
                    backups[p]=p.read_bytes() if p.exists() else None
                    temp=stage/Path(rel).name;write_json(temp,value)
                    if style_stage:
                        load_style_model(temp,_inside(root,job['reference']['image']))
                    else:
                        row=next(r for r in job['sources'] if r['review']==rel)
                        _review(temp,load_photo(_inside(root,row['image'])))
                for rel,value in changes.items():
                    target=_inside(root,rel)
                    tmp=target.with_name(target.name+'.agent-tmp');write_json(tmp,value)
                    tmp.replace(target);created.append(target)
                if not style_stage:
                    _preflight(root,job)
                write_json(receipt,{'schema_version':1,'stage':request['stage'],'analysis':data,
                    'analysis_sha256':_digest(data),'request':request,
                    'artifact_sha256':{rel:sha256_file(_inside(root,rel)) for rel in changes},
                    'aesthetic_status':'awaiting_user_review'})
        except Exception:
            for target in created:
                if backups[target] is None:
                    target.unlink(missing_ok=True)
                else:
                    target.write_bytes(backups[target])
            for rel in changes:
                _inside(root,rel).with_name(Path(rel).name+'.agent-tmp').unlink(missing_ok=True)
            receipt.unlink(missing_ok=True)
            raise
        path.unlink()
    if style_stage:
        return agent_request(root),0
    if render:
        audit_file = _inside(root,'style-effect-audit.json')
        if audit_file.exists():
            raise ValueError('Effect audit already exists; preserve this job and create a new version.')
        result, code = run_job(root)
        audit = audit_job(root)
        write_json(audit_file,audit)
        result['style_effect_audit']=str(audit_file)
        result['low_edit_review_sources']=[r['id'] for r in audit['results'] if r['low_edit_review_requested']]
        result['next']='View actual comparison/reference/output files and reconcile intended style with operator and edit audits. Technical success does not mean aesthetic acceptance.'
        return result, code
    return {'job_directory':str(root),'state':'ready_to_render','next':'run-job','aesthetic_status':'awaiting_user_review'},0
