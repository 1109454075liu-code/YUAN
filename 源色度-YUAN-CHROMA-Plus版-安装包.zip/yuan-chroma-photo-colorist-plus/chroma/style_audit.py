"""Expose effective style controls and measured edits; never infer aesthetic success."""
import argparse
import json
from pathlib import Path

import numpy as np

from .agent_schema import validate_model_contract
from .io import load_photo, pixel_hash, sha256_file, write_json
from .quality import edit_magnitude


def audit_model(value):
    model = value.get('style_model', value)
    validate_model_contract(model)
    op = model['operators']
    curve = np.asarray(op['tone_curve_L'], dtype=float)
    x = np.linspace(0, 100, 1001)
    y = np.interp(x, curve[:, 0], curve[:, 1])
    probes = [10, 25, 50, 75, 90]
    mapped = np.interp(probes, curve[:, 0], curve[:, 1])
    bands = [(10, 30), (35, 75), (80, 95)]
    slopes = [(float(np.interp(b, curve[:, 0], curve[:, 1])) -
               float(np.interp(a, curve[:, 0], curve[:, 1]))) / (b-a)
              for a, b in bands]
    scales = {family: float(op['global_chroma_scale']*op[family+'_chroma_scale'])
              for family in ('red', 'yellow', 'blue', 'green')}
    warnings = []
    if abs(slopes[1]-1) <= .05:
        warnings.append('MIDTONE_SPAN_NEAR_UNCHANGED: compare this numeric result with the intended contrast; do not describe a strong contrast change without evidence.')
    if float(np.max(abs(y-x))) <= 3.05:
        warnings.append('TONE_CURVE_LIGHT_CHANGE: this curve differs from identity by at most about 3 L units; deliberate subtle styles may be valid.')
    cancelled = [family for family, scale in scales.items()
                 if abs(scale-1) <= .05 and abs(op[family+'_chroma_scale']-1) >= .049]
    if cancelled:
        warnings.append('CHROMA_CONTROLS_CANCEL: global and family controls leave nearly unchanged chroma for '+', '.join(cancelled)+'. Check intent before rendering.')
    return {
        'schema_version': 1,
        'status': 'operator_review_required',
        'style_id': model['id'],
        'tone_curve_max_absolute_delta_L': float(np.max(abs(y-x))),
        'tone_curve_probes': [{'input_L': a, 'output_L': float(b), 'delta_L': float(b-a)}
                              for a, b in zip(probes, mapped)],
        'tone_span_slopes': dict(zip(('shadow_10_30', 'midtone_35_75', 'highlight_80_95'), slopes)),
        'fully_matched_family_chroma_multipliers': scales,
        'neutral_highlight_ab_bias': op['highlight_neutral_ab_bias'],
        'neutral_midtone_ab_bias': op['midtone_neutral_ab_bias'],
        'warnings': warnings,
        'interpretation': 'Numeric control diagnostics, not a style score. Family multipliers assume full membership, no overlapping families and no skin override; masks, hue changes, tints, source adaptation, strength and gamut mapping change actual output. Slopes summarize spans, not every local segment. Subtle or already-matching originals can be appropriate.',
    }


def audit_job(directory):
    from .jobs import _load_job, _inside, _read, _preflight, _run_record
    root, job = _load_job(directory)
    _preflight(root, job)
    run = _run_record(root, job)
    if len(run['completed']) != len(job['sources']):
        raise ValueError('All originals must have actual completed outputs before edit audit.')
    model_path = _inside(root, job['style_model'])
    model = _read(model_path)
    rows = []
    for source in job['sources']:
        key = source['id']
        before = load_photo(_inside(root, source['image']))
        output_path = _inside(root, f'results/{key}.png')
        after = load_photo(output_path)
        plan = _read(_inside(root, f'results/{key}.plan.json'))
        report = _read(_inside(root, f'results/{key}.report.json'))
        if before.rgb.shape != after.rgb.shape or before.orientation != after.orientation:
            raise ValueError('Output size/orientation differs from the bound original.')
        if (pixel_hash(before) != source['pixel_sha256'] or
                plan['source_pixel_sha256'] != pixel_hash(before) or
                plan['style_model_sha256'] != sha256_file(model_path) or
                plan['strength'] != job['strength'] or
                report['reproducibility']['output_pixel_sha256'] != pixel_hash(after)):
            raise ValueError('Output/plan/report is not bound to the current source, model and strength.')
        metrics = edit_magnitude(before, after)
        intentional_identity = job['strength'] == 0
        low_edit = not intentional_identity and (
            metrics['delta_E76_mean'] < 2 or metrics['fraction_delta_E76_above_2'] < .25)
        rows.append({'id': key, 'strength': plan['strength'], 'actual_pixel_edit': metrics,
                     'intentional_zero_strength': intentional_identity,
                     'low_edit_review_requested': bool(low_edit),
                     'technical_status': report['status'],
                     'source_pixel_sha256': pixel_hash(before),
                     'output_pixel_sha256': pixel_hash(after),
                     'aesthetic_status': 'awaiting_visual_and_user_review'})
    return {'schema_version': 1, 'status': 'visual_review_required',
            'operator_audit': audit_model(model), 'results': rows,
            'interpretation': 'Measured on actual PNG files. Low-edit thresholds (mean DeltaE76 <2 OR less than 25% above 2) are diagnostic heuristics, not rejection criteria or universal visibility thresholds. Do not inflate already-matching photos just to pass numbers. User feedback and reference-directed visual inspection govern revision.'}


def main(argv=None):
    parser = argparse.ArgumentParser(description='Inspect effective style controls or actual rendered edits. No grading or auto-acceptance.')
    sub = parser.add_subparsers(dest='mode', required=True)
    model = sub.add_parser('model'); model.add_argument('--model', required=True)
    job = sub.add_parser('job'); job.add_argument('--job-dir', required=True)
    for item in (model, job):
        item.add_argument('--output', required=True)
    args = parser.parse_args(argv)
    output = Path(args.output)
    if output.suffix.lower() != '.json' or output.exists() or output.is_symlink():
        parser.error('Use a new JSON output file; existing files are preserved.')
    if args.mode == 'model':
        if output.resolve() == Path(args.model).resolve():
            parser.error('Output cannot overwrite the style model.')
        value = json.loads(Path(args.model).read_text(encoding='utf-8'))
        result = audit_model(value)
    else:
        result = audit_job(args.job_dir)
    output.parent.mkdir(parents=True, exist_ok=True)
    write_json(output, result)
    print(json.dumps({'audit': str(output), 'status': result['status']}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
