"""Run the bundled style/actual-file audit from any working directory."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from chroma.style_audit import main

if __name__ == '__main__':
    raise SystemExit(main())
