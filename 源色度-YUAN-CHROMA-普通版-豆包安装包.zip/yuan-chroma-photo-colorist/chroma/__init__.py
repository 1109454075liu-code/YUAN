"""CHROMA: decisions are data; execution is deterministic pixel arithmetic."""
__version__ = "0.3.0"
