"""Bounded contracts for vision analysis. No executable model output is evaluated."""
import math


def obj(properties):
    return {"type":"object", "properties":properties, "required":list(properties), "additionalProperties":False}


def num(lo,hi):
    return {"type":"number", "minimum":lo, "maximum":hi}


def array(items,lo=0,hi=100):
    return {"type":"array", "items":items, "minItems":lo, "maxItems":hi}


TEXT = {"type":"string", "minLength":1, "maxLength":8000}
HASH = {"type":"string", "pattern":"^[0-9a-f]{64}$"}
PAIR = array(num(-20,20),2,2)
AXES = ("tone","contrast","white_balance","color_distribution","texture")
OP = {"tone_curve_L":array(array(num(0,100),2,2),2,32)}
OP.update({k:num(.3,1.3) for k in ("global_chroma_scale","red_chroma_scale","yellow_chroma_scale","blue_chroma_scale","green_chroma_scale")})
OP.update({"red_hue_target_deg":num(0,360), "red_hue_attraction":num(0,1),
           "red_hue_max_shift_deg":num(0,45), "red_lightness_lift_L":num(-12,12),
           "yellow_hue_rotation_deg":num(-30,30), "yellow_lightness_lift_L":num(-12,12),
           "blue_hue_rotation_deg":num(-45,45), "highlight_neutral_ab_bias":PAIR,
           "midtone_neutral_ab_bias":PAIR, "neutral_shadow_chroma_reduction":num(0,1)})
OP.update({k:{"type":"number","enum":[0]} for k in ("grain","blur","sharpen","halation")})
MODEL_SCHEMA = obj({"schema_version":{"type":"integer","enum":[1]},
    "profile_type":{"type":"string","enum":["photographic-grading-style-model"]},
    "id":TEXT,"name":TEXT,"status":TEXT,"reference_sha256":HASH,
    "style_axes":obj({k:obj({"description":TEXT,"confidence":num(0,1)}) for k in AXES}),
    "operators":obj(OP),
    "adaptation":obj({"exposure_target_median_L":num(20,80),"exposure_gain":num(0,.5),
        "exposure_limit_L":num(0,8),"white_balance_max_ab_correction":array(num(0,12),2,2),
        "face_source_retention":num(0,1),"skin_L_limit":num(0,12),"skin_hue_limit_deg":num(0,12),
        "blue_hue_limit_deg":num(0,45),"red_yellow_hue_limit_deg":num(0,45)}),
    "limits":array(TEXT,1,30),"provenance":obj({"method":TEXT,"numeric_operator_status":TEXT})})
BOXES = array(array(num(0,1),4,4),0,100)
REVIEW_SCHEMA = obj({"schema_version":{"type":"integer","enum":[1]},
    "source_pixel_sha256":HASH,"coordinate_space":{"type":"string","enum":["normalized_upright_display"]},
    "reviewed":{"type":"boolean","enum":[True]}, "reviewer":TEXT,"reason":TEXT,
    "faces_display":BOXES,"skin_display":BOXES,"sky_display":BOXES,
    "neutral_anchor_ROIs_display":BOXES,"white_balance_confidence":num(0,1)})
BUNDLE_SCHEMA = obj({"schema_version":{"type":"integer","enum":[1]}, "request_sha256":HASH,
    "style_model":{"anyOf":[MODEL_SCHEMA,{"type":"null"}]},
    "sources":array(obj({"id":{"type":"string","pattern":"^[0-9]{3}$"},"review":REVIEW_SCHEMA}),1,999)})


def validate(value,schema,path="analysis"):
    """Validate the exact subset emitted above, with no optional runtime dependency."""
    import re
    if "anyOf" in schema:
        for branch in schema["anyOf"]:
            try:
                validate(value,branch,path)
                return
            except ValueError:
                pass
        raise ValueError(path+": does not match any supported contract")
    kind=schema["type"]
    valid={"null":value is None,"object":isinstance(value,dict),"array":isinstance(value,list),
        "string":isinstance(value,str),"boolean":type(value) is bool,
        "integer":type(value) is int,"number":type(value) in (int,float)}[kind]
    if not valid:
        raise ValueError(path+": expected "+kind)
    if kind in ("number","integer"):
        if not math.isfinite(value) or value<schema.get("minimum",-math.inf) or value>schema.get("maximum",math.inf):
            raise ValueError(path+": number outside supported range")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError(path+": unsupported value")
    if kind=="object":
        if set(value)!=set(schema["required"]):
            raise ValueError(path+": missing or unknown fields "+str(set(value)^set(schema["required"])))
        for k,v in value.items():
            validate(v,schema["properties"][k],path+"."+k)
    elif kind=="array":
        if not schema.get("minItems",0)<=len(value)<=schema.get("maxItems",999):
            raise ValueError(path+": unsupported array length")
        for i,v in enumerate(value):
            validate(v,schema["items"],path+"["+str(i)+"]")
    elif kind=="string":
        if not schema.get("minLength",0)<=len(value)<=schema.get("maxLength",100000) or (schema.get("minLength",0)>0 and not value.strip()):
            raise ValueError(path+": missing or oversized text")
        if "pattern" in schema and not re.fullmatch(schema["pattern"],value):
            raise ValueError(path+": invalid identifier")


def validate_model_contract(model):
    # Historical provenance may carry iteration notes. Preserve those bytes, but
    # validate all renderer fields against the same bounded contract as new models.
    if not isinstance(model,dict):
        raise ValueError("Style model must be an object")
    projected={k:model.get(k) for k in MODEL_SCHEMA["properties"]}
    provenance=model.get("provenance",{})
    projected["provenance"]={k:provenance.get(k) for k in ("method","numeric_operator_status")}
    validate(projected,MODEL_SCHEMA,"style_model")
    from .style_renderer import validate_model
    validate_model(model)


def validate_review_contract(review):
    if not isinstance(review,dict) or set(review)-set(REVIEW_SCHEMA["properties"])-{"note"}:
        raise ValueError("Source review contains unknown fields")
    validate({k:review.get(k) for k in REVIEW_SCHEMA["properties"]},REVIEW_SCHEMA,"source_review")
    from .jobs import _boxes
    for key in ("faces_display","skin_display","sky_display","neutral_anchor_ROIs_display"):
        _boxes(review[key])
    if review["white_balance_confidence"]>0 and not review["neutral_anchor_ROIs_display"]:
        raise ValueError("Nonzero white balance confidence requires credible source neutral anchors")
