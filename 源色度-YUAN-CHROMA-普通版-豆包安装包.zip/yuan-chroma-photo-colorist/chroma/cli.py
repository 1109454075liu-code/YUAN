import argparse
import json
from pathlib import Path
import sys
import numpy as np
from PIL import Image
from .engine import PRESETS, load_preset, make_plan, render, validate_plan
from .io import load_photo, save_photo, sha256_file, write_json
from .quality import make_report, comparison
from .stats import analyze
from .style import extract_profile, load_profile


def _unit(value):
    try:
        number = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError('Expected a number in 0..1') from exc
    if not np.isfinite(number) or not 0 <= number <= 1:
        raise argparse.ArgumentTypeError('Expected a finite number in 0..1')
    return number


def _mask(path, shape):
    if not path:
        return None
    with Image.open(path) as image:
        if image.mode != 'L' or image.size != (shape[1], shape[0]) or getattr(image, 'n_frames', 1) != 1:
            raise ValueError('Protection mask must be a single 8-bit grayscale L image of the same stored dimensions.')
        if int(image.getexif().get(274, 1)) != 1:
            raise ValueError('Mask must use stored coordinates with no EXIF rotation (orientation=1).')
        return np.array(image, dtype=np.uint8)


def _guard_paths(outputs, inputs, force):
    paths = [Path(p).resolve() for p in outputs]
    originals = {Path(p).resolve() for p in inputs if p}
    if len(set(paths)) != len(paths) or set(paths) & originals:
        raise ValueError('Output paths must be distinct and must never overwrite an input, reference, mask or replay plan.')
    for path in paths:
        if path.exists() and any(original.exists() and path.samefile(original) for original in originals):
            raise ValueError('Output aliases an original input file (hard link); choose another output.')
        if path.exists() and not force:
            raise ValueError(f'Output already exists: {path.name}. Choose another path or use --force.')


def _execute(args):
    if args.command == 'grade' and (args.reference or args.style_profile) and not args.statistics_only:
        raise ValueError('Reference-style grading requires prior style analysis: use grade-style with --style-model. '
                         'Legacy color-statistics experiments require explicit --statistics-only.')
    output = Path(args.output)
    if output.suffix.lower() not in ('.png', '.jpg', '.jpeg'):
        raise ValueError('Output must end in .png, .jpg or .jpeg.')
    stem = output.with_suffix('')
    plan_path = Path(str(stem)+'.plan.json')
    report_path = Path(str(stem)+'.report.json')
    compare_path = Path(str(stem)+'.compare.png')
    _guard_paths([output, plan_path, report_path, compare_path],
                 [args.input, getattr(args, 'reference', None), args.protect_mask, getattr(args, 'plan', None),
                  getattr(args, 'style_profile', None), getattr(args, 'preset', None)], args.force)
    source = load_photo(args.input)
    mask = _mask(args.protect_mask, source.rgb.shape)
    if args.command == 'grade':
        reference = load_photo(args.reference) if args.reference else None
        profile = load_profile(args.style_profile) if args.style_profile else None
        plan = make_plan(source, load_preset(args.preset), args.strength, reference,
                         args.reference_strength, args.grain, args.seed, style_profile=profile)
        plan['protect_mask_sha256'] = sha256_file(args.protect_mask) if mask is not None else None
    else:
        reference = None
        plan = validate_plan(json.loads(Path(args.plan).read_text(encoding='utf-8')))
        actual_mask_hash = sha256_file(args.protect_mask) if mask is not None else None
        if actual_mask_hash != plan['protect_mask_sha256']:
            raise ValueError('Replay requires the original protect mask (matching SHA-256), or no mask if none was used.')
    result, diagnostics = render(source, plan, mask)
    save_photo(result, output)
    # Reports inspect decoded saved output, so JPEG errors are not hidden.
    saved = load_photo(output)
    report = make_report(source, saved, plan, diagnostics, mask)
    write_json(plan_path, plan)
    write_json(report_path, report)
    comparison(source, saved, compare_path, reference)
    print(json.dumps({'output': str(output), 'plan': str(plan_path), 'report': str(report_path),
                      'comparison': str(compare_path), 'quality_status': report['status']}, ensure_ascii=False))
    return 3 if args.strict_qc and report['issues'] else 0


def parser():
    p = argparse.ArgumentParser(description='CHROMA: deterministic photography color grading, no generative redraw.')
    sub = p.add_subparsers(dest='command', required=True)
    j = sub.add_parser('prepare-job', help='Prepare a portable original/reference task for Agent style analysis')
    j.add_argument('inputs', nargs='+', help='Original photos; HEIC supported via macOS local decoder')
    j.add_argument('--reference', required=True)
    j.add_argument('--job-dir', required=True, help='New directory; existing jobs are never replaced')
    j.add_argument('--style-model', help='Optional previously analyzed model for this exact reference')
    j.add_argument('--strength', type=_unit, default=1)
    j.add_argument('--freeze-style', action='store_true', help='Keep an existing style, reference, strength and renderer fixed before new-source analysis')
    for name in ('job-status','run-job'):
        j = sub.add_parser(name, help='Inspect task readiness' if name=='job-status' else 'Render all reviewed originals, safely resume completed results')
        j.add_argument('--job-dir', required=True)
    j=sub.add_parser('agent-start',help='Host Agent intake: prepare images and export the first bound visual-analysis request')
    j.add_argument('inputs',nargs='+')
    j.add_argument('--reference',required=True)
    j.add_argument('--job-dir',required=True)
    j.add_argument('--style-model',help='Optional analyzed model bound to this exact reference')
    j.add_argument('--strength',type=_unit,default=1)
    j.add_argument('--freeze-style',action='store_true')
    j=sub.add_parser('agent-request',help='Export the current stage and images for a vision-capable host Agent')
    j.add_argument('--job-dir',required=True)
    j=sub.add_parser('agent-submit',help='Validate and commit one bound analysis stage; no manual review files')
    j.add_argument('--job-dir',required=True)
    j.add_argument('--analysis',required=True)
    j.add_argument('--render',action='store_true',help='Render automatically after all source analyses pass validation')
    j=sub.add_parser('agent-api',help='Optional API analysis then deterministic local grading')
    j.add_argument('--job-dir',required=True)
    j.add_argument('--model',required=True,help='Configured vision model supporting Responses and strict JSON schema')
    j.add_argument('--allow-network',action='store_true',help='Explicitly submit upright previews to the vision API')
    sub.add_parser('presets', help='List bundled presets')
    e = sub.add_parser('extract-style', help='Legacy: extract auxiliary color statistics; NOT grading-style analysis')
    e.add_argument('input')
    e.add_argument('--output', '-o', required=True)
    e.add_argument('--name', default='Reference color style')
    e.add_argument('--force', action='store_true')
    a = sub.add_parser('analyze', help='Write exposure/color statistics')
    a.add_argument('input')
    a.add_argument('--output')
    a.add_argument('--force', action='store_true')
    v = sub.add_parser('validate-style', help='Validate Agent style analysis and its reference identity before grading')
    v.add_argument('--style-model', required=True)
    v.add_argument('--reference', required=True)
    for name in ('grade-style','replay-style'):
        a = sub.add_parser(name, help='Execute a prior grading-style model' if name=='grade-style' else 'Replay a source-bound style plan')
        a.add_argument('input')
        a.add_argument('--output','-o',required=True)
        if name=='grade-style':
            a.add_argument('--style-model',required=True,help='Agent-inferred photographic-grading-style-model JSON; statistics profiles are rejected')
            a.add_argument('--reference',help='Optional original reference; SHA-256 must match the analyzed model')
            a.add_argument('--faces',required=True)
            a.add_argument('--skin-scope',required=True)
            a.add_argument('--context',required=True,help='Source-bound exposure/WB/region analysis')
            a.add_argument('--strength',type=_unit,default=1)
        else:
            a.add_argument('--plan',required=True)
    for command in ('grade', 'replay'):
        a = sub.add_parser(command, help='Grade a photo' if command == 'grade' else 'Reproduce a saved plan without the reference image')
        a.add_argument('input')
        a.add_argument('--output', '-o', required=True)
        a.add_argument('--protect-mask', help='Same-size grayscale L; white freezes pixels, black permits grading')
        a.add_argument('--strict-qc', action='store_true', help='Exit 3 for quality issues, while keeping files for review')
        a.add_argument('--force', action='store_true', help='Replace existing outputs; never original inputs')
        if command == 'grade':
            a.add_argument('--preset', default='golden-film', help='Bundled id or custom JSON file')
            refs = a.add_mutually_exclusive_group()
            refs.add_argument('--reference')
            refs.add_argument('--style-profile', help='Reusable JSON produced by extract-style')
            a.add_argument('--statistics-only', action='store_true', help='Explicit legacy color-statistics experiment; not reference grading-style analysis')
            a.add_argument('--strength', type=_unit, default=.75, help='0..1; scales the complete grading including reference and grain')
            a.add_argument('--reference-strength', type=_unit, default=.35, help='0..1; bounded reference influence inside overall strength')
            a.add_argument('--grain', type=_unit, default=0, help='0..1; optional seeded monochrome noise, default off')
            a.add_argument('--seed', type=int, default=42)
        else:
            a.add_argument('--plan', required=True)
    d = sub.add_parser('demo', help='Run bundled real and synthetic cases, write an aggregate summary')
    d.add_argument('--directory', default='examples/results')
    d.add_argument('--force', action='store_true')
    return p


def main(argv=None):
    # JSON output is a UTF-8 protocol, including redirected Windows Agent pipes.
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'):
            stream.reconfigure(encoding='utf-8')
    args = parser().parse_args(argv)
    try:
        if args.command in ('agent-start','agent-request','agent-submit','agent-api'):
            from .agent import agent_start,agent_request,submit_analysis
            code=0
            if args.command=='agent-start':
                result=agent_start(args.inputs,args.reference,args.job_dir,args.style_model,args.strength,args.freeze_style)
            elif args.command=='agent-request':
                result=agent_request(args.job_dir)
            elif args.command=='agent-submit':
                result,code=submit_analysis(args.job_dir,args.analysis,args.render)
            else:
                from .vision_api import run_api
                result,code=run_api(args.job_dir,args.model,args.allow_network)
            print(json.dumps(result,ensure_ascii=False,indent=2))
            return code
        if args.command in ('prepare-job','job-status','run-job'):
            from .jobs import prepare_job, job_status, run_job
            if args.command == 'prepare-job':
                result = prepare_job(args.inputs,args.reference,args.job_dir,args.style_model,args.strength,args.freeze_style)
                code = 0
            elif args.command == 'job-status':
                result = job_status(args.job_dir)
                code = 0
            else:
                result,code = run_job(args.job_dir)
            print(json.dumps(result,ensure_ascii=False,indent=2))
            return code
        if args.command == 'validate-style':
            from .workflow import load_style_model
            model = load_style_model(args.style_model,args.reference)
            print(json.dumps({'status':'style_model_validated','style_id':model['id'],'next':'grade-style'},ensure_ascii=False))
            return 0
        if args.command in ('grade-style','replay-style'):
            from .workflow import execute_style
            return execute_style(args)
        if args.command == 'presets':
            for path in sorted(PRESETS.glob('*.json')):
                p = load_preset(str(path))
                print(f"{p['id']}: {p['name']}")
            return 0
        if args.command == 'extract-style':
            _guard_paths([args.output], [args.input], args.force)
            profile = extract_profile(load_photo(args.input), args.name)
            write_json(args.output, profile)
            print(json.dumps({'style_profile': args.output, 'name': profile['name']}, ensure_ascii=False))
            return 0
        if args.command == 'analyze':
            if args.output:
                _guard_paths([args.output], [args.input], args.force)
            report = analyze(load_photo(args.input))
            if args.output:
                write_json(args.output, report)
            else:
                print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0
        if args.command == 'demo':
            from .demo import run_demo
            return run_demo(args.directory, args.force)
        return _execute(args)
    except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f'CHROMA: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
