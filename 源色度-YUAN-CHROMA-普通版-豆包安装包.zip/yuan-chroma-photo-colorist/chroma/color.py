"""sRGB <-> CIELAB with D65 reference white (not ICC's D50 Lab)."""
import numpy as np

RGB_XYZ = np.array([[0.4124564, 0.3575761, 0.1804375],
                    [0.2126729, 0.7151522, 0.0721750],
                    [0.0193339, 0.1191920, 0.9503041]], dtype=np.float32)
XYZ_RGB = np.linalg.inv(RGB_XYZ).astype(np.float32)
WHITE = np.array([0.95047, 1.0, 1.08883], dtype=np.float32)


def rgb_to_lab(rgb):
    rgb = np.asarray(rgb, dtype=np.float32)
    linear = np.where(rgb <= 0.04045, rgb / 12.92,
                      ((rgb + 0.055) / 1.055) ** 2.4)
    xyz = (linear @ RGB_XYZ.T) / WHITE
    d = 6 / 29
    f = np.where(xyz > d**3, np.cbrt(xyz), xyz / (3*d*d) + 4/29)
    return np.stack((116*f[..., 1]-16, 500*(f[..., 0]-f[..., 1]),
                     200*(f[..., 1]-f[..., 2])), axis=-1)


def lab_to_rgb(lab):
    fy = (lab[..., 0] + 16) / 116
    f = np.stack((fy + lab[..., 1]/500, fy, fy-lab[..., 2]/200), axis=-1)
    d = 6/29
    xyz = np.where(f > d, f**3, 3*d*d*(f-4/29)) * WHITE
    linear = xyz @ XYZ_RGB.T
    # Negative linear components use the linear segment; no invalid fractional powers.
    return np.where(linear <= 0.0031308, 12.92*linear,
                    1.055*np.maximum(linear, 0)**(1/2.4)-0.055)


def gamut_map(lab):
    """Reduce chroma at fixed L/hue instead of clipping each RGB channel."""
    rgb = lab_to_rgb(lab)
    outside = np.any((rgb < 0) | (rgb > 1), axis=-1)
    if outside.any():
        base = lab[outside].copy()
        low = np.zeros(len(base), dtype=np.float32)
        high = np.ones(len(base), dtype=np.float32)
        for _ in range(12):
            mid = (low+high)/2
            candidate = base.copy()
            candidate[:, 1:] *= mid[:, None]
            c = lab_to_rgb(candidate)
            valid = np.all((c >= 0) & (c <= 1), axis=-1)
            low = np.where(valid, mid, low)
            high = np.where(valid, high, mid)
        base[:, 1:] *= low[:, None]
        rgb[outside] = lab_to_rgb(base)
    return np.clip(rgb, 0, 1), int(outside.sum())


def rgb_to_hsv(rgb):
    maximum, minimum = rgb.max(axis=-1), rgb.min(axis=-1)
    delta = maximum-minimum
    divisor = np.maximum(delta, 1e-8)
    index = rgb.argmax(axis=-1)
    hue = np.where(index == 0, (rgb[..., 1]-rgb[..., 2])/divisor,
                   np.where(index == 1, 2+(rgb[..., 2]-rgb[..., 0])/divisor,
                            4+(rgb[..., 0]-rgb[..., 1])/divisor)) / 6
    hue = np.where(delta > 1e-8, hue % 1, 0)
    return np.stack((hue, delta/np.maximum(maximum, 1e-8), maximum), axis=-1)


def hsv_to_rgb(hsv):
    h, s, v = np.moveaxis(hsv, -1, 0)
    i = np.floor(h*6).astype(int) % 6
    f = h*6-np.floor(h*6)
    p, q, t = v*(1-s), v*(1-f*s), v*(1-(1-f)*s)
    r = np.choose(i, [v, q, p, p, t, v])
    g = np.choose(i, [t, v, v, q, p, p])
    b = np.choose(i, [p, p, t, v, v, q])
    return np.stack((r, g, b), axis=-1)


def smooth(lo, hi, values):
    x = np.clip((values-lo)/(hi-lo), 0, 1)
    return x*x*(3-2*x)


def masks(rgb):
    """Conservative color proxies, NOT semantic sky/face segmentation."""
    h, s, v = np.moveaxis(rgb_to_hsv(rgb), -1, 0)
    skin = (h < 0.15) & (s > 0.10) & (s < 0.68) & (v > 0.20)
    blue = (h > 0.48) & (h < 0.73) & (s > 0.08) & (v > 0.15)
    green = smooth(0.16, 0.22, h) * (1-smooth(0.38, 0.46, h)) * smooth(0.05, 0.2, s)
    return skin, blue, green


def protect_hues(source, target, skin_limit=6, blue_limit=8):
    original = rgb_to_hsv(source)
    result = rgb_to_hsv(target)
    skin, blue, _ = masks(source)
    delta = (result[..., 0]-original[..., 0]+0.5) % 1-0.5
    for mask, limit, floor in ((skin, skin_limit, 0.78), (blue, blue_limit, 0.62)):
        result[..., 0] = np.where(mask, (original[..., 0]+np.clip(delta, -limit/360, limit/360)) % 1,
                                 result[..., 0])
        result[..., 1] = np.where(mask, np.clip(result[..., 1], original[..., 1]*floor,
                                              np.minimum(original[..., 1]*1.10, 1)), result[..., 1])
    return hsv_to_rgb(result)
