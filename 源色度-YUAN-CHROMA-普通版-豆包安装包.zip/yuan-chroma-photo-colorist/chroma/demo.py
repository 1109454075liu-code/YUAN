"""Real photos plus clearly labeled procedural stress fixtures; never AI-generated photos."""
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from .io import write_json


def create_fixtures(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    w, h = 640, 480
    y, x = np.mgrid[:h, :w]
    rgb = np.empty((h, w, 3), dtype=np.uint8)
    rgb[..., 0] = 85 + y//8
    rgb[..., 1] = 155 + y//16
    rgb[..., 2] = 218 - y//12
    image = Image.fromarray(rgb)
    d = ImageDraw.Draw(image)
    d.rectangle((0, 230, w, h), fill=(53, 98, 58))
    d.rectangle((35, 130, 190, 360), fill=(205, 198, 181), outline=(28, 28, 26), width=4)
    for bx in range(45, 180, 30):
        for by in range(150, 340, 35):
            d.rectangle((bx, by, bx+15, by+18), fill=(35, 49, 55))
    d.ellipse((260, 120, 350, 230), fill=(195, 139, 105), outline=(68, 45, 35), width=3)
    d.ellipse((280, 160, 286, 166), fill=(28, 24, 20))
    d.ellipse((322, 160, 328, 166), fill=(28, 24, 20))
    d.line((290, 193, 320, 193), fill=(81, 39, 35), width=3)
    d.rectangle((275, 230, 340, 375), fill=(48, 65, 84))
    d.ellipse((420, 270, 530, 375), fill=(223, 114, 30))
    d.ellipse((475, 355, 555, 423), fill=(220, 152, 145))
    d.ellipse((548, 308, 603, 390), fill=(165, 173, 53))
    d.rectangle((20, 385, 410, 459), fill=(232, 230, 220))
    d.text((30, 400), 'SYNTHETIC QA / CHROMA 2026\nTEXT 012345 | skin / blue / fruit proxies', fill=(20, 22, 25))
    image.save(directory/'synthetic-scene.png')
    mask = Image.new('L', (w, h), 0)
    md = ImageDraw.Draw(mask)
    md.rectangle((20, 385, 410, 459), fill=255)
    mask.save(directory/'synthetic-protect-mask.png')
    dark = np.asarray(image, dtype=np.float32)*.18
    Image.fromarray(np.rint(dark).astype(np.uint8)).save(directory/'synthetic-night.png')
    # Complete 8-bit neutral ramp, saturated patches, high-frequency checkerboard.
    chart = Image.new('RGB', (640, 400), '#404040')
    cd = ImageDraw.Draw(chart)
    for col in range(640):
        value = int(round(col/639*255))
        cd.line((col, 0, col, 95), fill=(value,)*3)
    colors = [(220, 157, 115), (129, 80, 54), (72, 141, 210), (110, 170, 224),
              (40, 128, 63), (111, 151, 38), (240, 128, 30), (231, 173, 180),
              (254, 250, 220), (2, 3, 5), (255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 255), (0, 0, 0), (128, 128, 128)]
    for i, color in enumerate(colors):
        xx, yy = i % 8*80, 105+i//8*95
        cd.rectangle((xx, yy, xx+79, yy+85), fill=color)
    for yy in range(305, 385, 4):
        for xx in range(0, 640, 4):
            cd.rectangle((xx, yy, xx+3, yy+3), fill=(220,)*3 if (xx+yy)//4 % 2 else (40,)*3)
    cd.text((10, 390), 'PROCEDURAL TEST CHART - NOT A PHOTOGRAPH', fill='white')
    chart.save(directory/'synthetic-chart.png')
    return directory


def run_demo(directory, force=False):
    from .cli import main
    # The installed CLI can generate fixtures even when real project photos are unavailable.
    directory = Path(directory)
    fixtures = directory/'inputs'
    real = Path(__file__).resolve().parent.parent/'examples'/'inputs'
    summary_path = directory/'summary.json'
    if directory.exists() and any(directory.iterdir()) and not force:
        raise ValueError('Demo directory is nonempty. Choose another directory or use --force.')
    create_fixtures(fixtures)
    jobs = [('synthetic-chart', fixtures/'synthetic-chart.png', None, None, 0),
            ('synthetic-scene', fixtures/'synthetic-scene.png', None, fixtures/'synthetic-protect-mask.png', 0),
            ('synthetic-night', fixtures/'synthetic-night.png', None, None, 0),
            ('synthetic-grain', fixtures/'synthetic-scene.png', None, None, .3)]
    reference = real/'IMG_3112(1).jpeg'
    if (real/'IMG_2927.jpeg').is_file() and reference.is_file():
        jobs.insert(0, ('landscape-golden', real/'IMG_2927.jpeg', reference, None, 0))
        jobs.append(('harbor-golden', reference, None, None, 0))
        for preset in ('golden-film-vivid', 'hasselblad-natural', 'fujifilm-classic', 'fujifilm-nostalgic'):
            jobs.append((f'landscape-{preset}', real/'IMG_2927.jpeg', reference if preset == 'golden-film-vivid' else None, None, 0))
        profile_command = ['extract-style', str(reference), '-o', str(directory/'harbor.style.json'), '--name', 'Warm harbor reference']
        if force:
            profile_command.append('--force')
        if main(profile_command) != 0:
            raise ValueError('Failed to extract the reusable harbor style profile.')
    pumpkin = real/'IMG_3107-original.png'
    if pumpkin.is_file():
        jobs.append(('pumpkin-golden-film-vivid', pumpkin, reference if reference.is_file() else None, None, 0))
    reports, codes = [], []
    for name, source, ref, mask, grain in jobs:
        output = directory/f'{name}.png'
        command = ['grade', str(source), '-o', str(output), '--strength', '.75', '--grain', str(grain), '--strict-qc']
        for preset in ('golden-film-vivid', 'hasselblad-natural', 'fujifilm-classic', 'fujifilm-nostalgic'):
            if name.endswith(preset):
                command += ['--preset', preset]
                break
        if force:
            command.append('--force')
        if ref:
            command += ['--reference', str(ref), '--reference-strength', '.5', '--statistics-only']
        if mask:
            command += ['--protect-mask', str(mask)]
        code = main(command)
        codes.append(code)
        report_path = output.with_suffix('.report.json')
        if report_path.exists():
            import json
            r = json.loads(report_path.read_text(encoding='utf-8'))
            reports.append({'case': name, 'exit_code': code, 'status': r['status'], 'issues': r['issues'],
                            'stored_size': r['output']['stored_size'],
                            'display_size': r['output']['display_size'],
                            'geometry_size_equal': r['preservation']['stored_dimensions_equal'],
                            'gradient_correlation': r['preservation']['luminance_gradient_correlation_QA_proxy'],
                            'protected_pixels_exact': r['preservation']['fully_protected_pixels_exact'],
                            'reference_match': r['reference_match'], 'color_protection': r['color_protection'],
                            'edit_magnitude': r['edit_magnitude']})
    write_json(summary_path, {'cases': reports, 'all_strict_qc_passed': all(c == 0 for c in codes),
                              'real_assets': [p.name for p in (real/'IMG_2927.jpeg', reference, pumpkin) if p.is_file()],
                              'unavailable_assets': ['IMG_3111.jpeg', 'IMG_3108.jpeg', 'IMG_3110.jpeg'],
                              'fixture_notice': 'Synthetic files are procedural QA scenes, not substituted real fruit photos.'})
    if all((directory/f'{name}.png').is_file() for name in ('landscape-golden', 'landscape-golden-film-vivid',
                                                         'landscape-hasselblad-natural', 'landscape-fujifilm-classic',
                                                         'landscape-fujifilm-nostalgic')):
        _style_sheet(real/'IMG_2927.jpeg', directory)
    return 0 if all(c == 0 for c in codes) else 3


def _style_sheet(original, directory):
    from PIL import ImageOps
    panels = [('ORIGINAL', original), ('HASSELBLAD NATURAL (EXPERIMENTAL)', directory/'landscape-hasselblad-natural.png'),
              ('FUJIFILM CLASSIC (EXPERIMENTAL)', directory/'landscape-fujifilm-classic.png'),
              ('FUJIFILM NOSTALGIC (EXPERIMENTAL)', directory/'landscape-fujifilm-nostalgic.png'),
              ('GOLDEN FILM + HARBOR REFERENCE', directory/'landscape-golden.png'),
              ('GOLDEN FILM VIVID + HARBOR REFERENCE', directory/'landscape-golden-film-vivid.png')]
    width, height, gap = 340, 480, 18
    canvas = Image.new('RGB', (3*width+4*gap, 2*height+3*gap), '#131917')
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default(size=13)
    for index, (label, path) in enumerate(panels):
        with Image.open(path) as photo:
            image = ImageOps.exif_transpose(photo).convert('RGB')
            image.thumbnail((width, height-36))
        x, y = gap+(index % 3)*(width+gap), gap+(index//3)*(height+gap)
        draw.text((x, y), label, fill='#e8e8db', font=font)
        canvas.paste(image, (x+(width-image.width)//2, y+30+(height-36-image.height)//2))
    canvas.save(directory/'style-contact-sheet.png')
