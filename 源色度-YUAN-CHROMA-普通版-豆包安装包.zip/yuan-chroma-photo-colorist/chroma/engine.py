"""All edits act on color at the same (row, column). No spatial image transforms."""
import copy
import json
from pathlib import Path
import numpy as np
from . import __version__
from .color import rgb_to_lab, rgb_to_hsv, gamut_map, smooth, masks, protect_hues
from .io import Photo, pixel_hash
from .stats import sample_pixels, describe, QUANTILES

PRESETS = Path(__file__).parent / 'presets'


def number(value, lo, hi, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value) or not lo <= value <= hi:
        raise ValueError(f'{name} must be finite and within [{lo}, {hi}].')
    return float(value)


def validate_preset(p):
    required = {'schema_version', 'id', 'name', 'description', 'tone_curve', 'saturation',
                'shadow_ab', 'midtone_ab', 'highlight_ab', 'green_chroma_scale',
                'green_ab_shift', 'auto_exposure_limit_L', 'skin_hue_limit_deg', 'blue_hue_limit_deg'}
    if not isinstance(p, dict) or set(p) != required or p['schema_version'] != 1:
        raise ValueError('Preset schema mismatch (version 1 and exact supported keys required).')
    if not all(isinstance(p[k], str) and p[k] for k in ('id', 'name', 'description')):
        raise ValueError('Preset id/name/description must be nonempty strings.')
    curve = np.asarray(p['tone_curve'], dtype=float)
    if curve.ndim != 2 or curve.shape[1] != 2 or len(curve) < 2 or not np.isfinite(curve).all():
        raise ValueError('tone_curve must contain finite [input L, output L] pairs.')
    if curve[0, 0] != 0 or curve[-1, 0] != 100 or (curve < 0).any() or (curve > 100).any():
        raise ValueError('Curve must span 0..100 L and remain inside 0..100.')
    slopes = np.diff(curve[:, 1])/np.diff(curve[:, 0]) if (np.diff(curve[:, 0]) > 0).all() else np.array([0])
    if (slopes < .35).any() or (slopes > 2).any():
        raise ValueError('Curve must be strictly monotonic, with slope 0.35..2 to retain tonal detail.')
    for key in ('shadow_ab', 'midtone_ab', 'highlight_ab', 'green_ab_shift'):
        if not isinstance(p[key], list) or len(p[key]) != 2:
            raise ValueError(f'{key} must be a two-value vector.')
        for v in p[key]:
            number(v, -8, 8, key)
    for key, lo, hi in (('saturation', .65, 1.1), ('green_chroma_scale', .65, 1.1),
                        ('auto_exposure_limit_L', 0, 6), ('skin_hue_limit_deg', 0, 6),
                        ('blue_hue_limit_deg', 0, 8)):
        number(p[key], lo, hi, key)
    return p


def load_preset(name):
    path = PRESETS / f'{name}.json' if not Path(name).is_file() else Path(name)
    if not path.is_file():
        raise ValueError(f'Unknown preset: {name}')
    return validate_preset(json.loads(path.read_text(encoding='utf-8')))


def _preset_lab(rgb, preset, exposure):
    lab = rgb_to_lab(rgb)
    original_l = lab[..., 0].copy()
    l = np.clip(original_l + exposure, 0, 100)
    curve = np.array(preset['tone_curve'])
    lab[..., 0] = np.interp(l, curve[:, 0], curve[:, 1])
    # Protect existing dark and bright detail from large adaptive shifts.
    lab[..., 0] = np.clip(lab[..., 0], np.maximum(0, original_l-10), np.minimum(99.8, original_l+10))
    skin, blue, green = masks(rgb)
    lab[..., 1:] *= preset['saturation']
    lab[..., 1:] *= (1 + green*(preset['green_chroma_scale']-1))[..., None]
    lab[..., 1:] += green[..., None]*np.array(preset['green_ab_shift'])
    shadow = 1-smooth(20, 55, original_l)
    highlight = smooth(55, 90, original_l)
    mid = 1-shadow-highlight
    split = (shadow[..., None]*preset['shadow_ab'] + mid[..., None]*preset['midtone_ab'] +
             highlight[..., None]*preset['highlight_ab'])
    split *= np.where(skin, .45, np.where(blue, .5, 1))[..., None]
    lab[..., 1:] += split
    return lab


def _reference_parameters(base, reference):
    ldelta = np.clip(np.array(reference['L_percentiles'])-base['L_percentiles'], -4, 4)
    # Enforce a positive-slope target curve; sparse flat distributions cannot amplify contrast.
    xp, positions = np.unique(base['L_percentiles'], return_index=True)
    targets = xp + ldelta[positions]
    for i in range(1, len(xp)):
        targets[i] = targets[i-1] + np.clip(targets[i]-targets[i-1], .7*(xp[i]-xp[i-1]), 1.3*(xp[i]-xp[i-1]))
    offsets = np.clip(targets-xp, -4, 4)
    band_offsets, band_scales, band_centers = [], [], []
    global_delta = np.clip(np.array(reference['ab_mean'])-base['ab_mean'], -6, 6)
    for b, r in zip(base['tone_bands'], reference['tone_bands']):
        coverage = min(b['count']/base['sample_count'], r['count']/reference['sample_count'])
        confidence = min(1, coverage/.10) if min(b['count'], r['count']) >= 64 else 0
        delta = np.clip(np.array(r['ab_mean'])-b['ab_mean'], -6, 6)
        band_offsets.append((delta*confidence + global_delta*(1-confidence)).tolist())
        ratio = np.clip(np.array(r['ab_std'])/np.maximum(b['ab_std'], 4), .85, 1.05)
        band_scales.append((1+(ratio-1)*confidence).tolist())
        band_centers.append(b['ab_mean'])
    return {'L_knots': xp.tolist(), 'L_offsets': offsets.tolist(),
            'ab_offsets': band_offsets, 'ab_scales': band_scales, 'ab_centers': band_centers}


def make_plan(source, preset, strength=.75, reference=None, reference_strength=.35, grain=0, seed=42, style_profile=None):
    validate_preset(preset)
    if reference is not None and style_profile is not None:
        raise ValueError('Choose a reference image OR a reusable style profile.')
    number(strength, 0, 1, 'strength')
    number(reference_strength, 0, 1, 'reference_strength')
    number(grain, 0, 1, 'grain')
    if isinstance(seed, bool) or not isinstance(seed, int) or not 0 <= seed <= 2**32-1:
        raise ValueError('seed must be an integer in 0..4294967295.')
    sample = sample_pixels(source)
    stats = describe(sample)
    # Gentle compensation only, not white balance by gray-world or night-to-day normalization.
    median_l = stats['L_percentiles'][3]
    exposure = float(np.clip((50-median_l)*.12, -preset['auto_exposure_limit_L'], preset['auto_exposure_limit_L']))
    plan = {'schema_version': 1, 'engine_version': __version__, 'preset': copy.deepcopy(preset),
            'source': {**source.metadata, 'normalized_pixel_sha256': pixel_hash(source)},
            'source_statistics': stats, 'strength': strength, 'reference_strength': reference_strength,
            'grain': grain, 'seed': seed, 'exposure_L': exposure,
            'reference': None, 'reference_transform': None, 'protect_mask_sha256': None}
    if reference is not None or style_profile is not None:
        if style_profile is not None:
            from .style import validate_profile
            validate_profile(style_profile)
            refstats = copy.deepcopy(style_profile['statistics'])
            refmeta = {**copy.deepcopy(style_profile['source']), 'style_profile_name': style_profile['name'],
                       'source_kind': 'reusable_style_profile'}
        else:
            refstats = describe(sample_pixels(reference))
            refmeta = copy.deepcopy(reference.metadata)
        baseline, _ = gamut_map(_preset_lab(sample, preset, exposure))
        plan['reference'] = {**refmeta, 'statistics': refstats}
        plan['reference_transform'] = _reference_parameters(describe(baseline), refstats)
    return plan


def validate_plan(plan):
    required = {'schema_version', 'engine_version', 'preset', 'source', 'source_statistics', 'strength',
                'reference_strength', 'grain', 'seed', 'exposure_L', 'reference',
                'reference_transform', 'protect_mask_sha256'}
    if not isinstance(plan, dict) or set(plan) != required or plan['schema_version'] != 1 or plan['engine_version'] != __version__:
        raise ValueError('Unsupported plan schema/engine version.')
    validate_preset(plan['preset'])
    for key in ('strength', 'reference_strength', 'grain'):
        number(plan[key], 0, 1, key)
    number(plan['exposure_L'], -6, 6, 'exposure_L')
    seed = plan['seed']
    if isinstance(seed, bool) or not isinstance(seed, int) or not 0 <= seed <= 2**32-1:
        raise ValueError('Invalid plan seed.')
    transform = plan['reference_transform']
    if transform is not None:
        if set(transform) != {'L_knots', 'L_offsets', 'ab_offsets', 'ab_scales', 'ab_centers'}:
            raise ValueError('Invalid reference transform keys.')
        x, y = np.asarray(transform['L_knots']), np.asarray(transform['L_offsets'])
        if x.ndim != 1 or x.size < 1 or x.shape != y.shape or not np.isfinite(x).all() or not np.isfinite(y).all():
            raise ValueError('Invalid reference luminance transform.')
        if (x < 0).any() or (x > 100).any() or (np.diff(x) <= 0).any() or (np.abs(y) > 4).any():
            raise ValueError('Reference luminance transform exceeds constraints.')
        if (np.diff(x+y) <= 0).any():
            raise ValueError('Reference luminance mapping must remain monotonic.')
        for key, lo, hi in (('ab_offsets', -6, 6), ('ab_scales', .85, 1.05), ('ab_centers', -128, 128)):
            array = np.asarray(transform[key], dtype=float)
            if array.shape != (3, 2) or not np.isfinite(array).all() or (array < lo).any() or (array > hi).any():
                raise ValueError(f'Invalid reference {key}.')
    return plan


def _transform(rgb, plan):
    lab = _preset_lab(rgb, plan['preset'], plan['exposure_L'])
    reference = plan['reference_transform']
    if reference is not None and plan['reference_strength'] > 0:
        amount = plan['reference_strength']
        l = lab[..., 0].copy()
        skin, blue, _ = masks(rgb)
        protection = np.where(skin, .25, np.where(blue, .4, 1))
        delta_l = np.interp(l, reference['L_knots'], reference['L_offsets'])
        lab[..., 0] = np.clip(l + delta_l*amount*np.where(skin, .5, 1), 0, 99.8)
        shadow = 1-smooth(20, 55, l)
        highlight = smooth(55, 90, l)
        mid = 1-shadow-highlight
        chroma_delta = np.zeros_like(lab[..., 1:])
        for index, weight in enumerate((shadow, mid, highlight)):
            center = np.asarray(reference['ab_centers'][index])
            scale = np.asarray(reference['ab_scales'][index])
            offset = np.asarray(reference['ab_offsets'][index])
            delta = (lab[..., 1:]-center)*(scale-1)+offset
            chroma_delta += weight[..., None]*np.clip(delta, -6, 6)
        lab[..., 1:] += chroma_delta * (amount*protection)[..., None]
    # Per-pixel lightness/chroma bounds apply independently of the reference scene.
    original = rgb_to_lab(rgb)
    skin, blue, _ = masks(rgb)
    l_bound = np.where(skin, 6, 12)
    lab[..., 0] = np.clip(lab[..., 0], np.maximum(0, original[..., 0]-l_bound), np.minimum(99.8, original[..., 0]+l_bound))
    delta_ab = lab[..., 1:]-original[..., 1:]
    distance = np.linalg.norm(delta_ab, axis=-1)
    limit = np.where(skin, 6, np.where(blue, 9, 16))
    lab[..., 1:] = original[..., 1:] + delta_ab*np.minimum(1, limit/np.maximum(distance, 1e-8))[..., None]
    target, mapped = gamut_map(lab)
    return target, mapped


def render(source, plan, protect_mask=None):
    validate_plan(plan)
    if pixel_hash(source) != plan['source']['normalized_pixel_sha256']:
        raise ValueError('Source pixel hash differs from the plan. Create a new plan for this image.')
    if protect_mask is not None and protect_mask.shape != source.rgb.shape[:2]:
        raise ValueError('Protection mask must match source stored dimensions; it is never resized.')
    output = np.empty_like(source.rgb)
    rng = np.random.Generator(np.random.PCG64(plan['seed']))
    mapped_count = 0
    # Fixed strips bound memory and form part of the versioned reproducibility contract.
    for row in range(0, source.rgb.shape[0], 128):
        block = source.rgb[row:row+128].astype(np.float32)/255
        if plan['strength'] == 0:
            output[row:row+128] = source.rgb[row:row+128]
            continue
        target, mapped = _transform(block, plan)
        mapped_count += mapped
        result = block + plan['strength']*(target-block)
        if plan['grain']:
            noise = rng.normal(0, .004*plan['grain']*plan['strength'], size=block.shape[:2]).astype(np.float32)
            l = rgb_to_lab(block)[..., 0]/100
            noise *= .35+.65*(1-np.abs(l-.5)*2)
            result = np.clip(result+noise[..., None], 0, 1)
        result = protect_hues(block, result, plan['preset']['skin_hue_limit_deg'], plan['preset']['blue_hue_limit_deg'])
        if protect_mask is not None:
            amount = 1-protect_mask[row:row+128].astype(np.float32)/255
            result = block+(result-block)*amount[..., None]
        quantized = _quantize_guard(source.rgb[row:row+128], result, plan['preset'])
        if protect_mask is not None:
            frozen = protect_mask[row:row+128] == 255
            quantized[frozen] = source.rgb[row:row+128][frozen]
        if source.alpha is not None:
            invisible = source.alpha[row:row+128] == 0
            quantized[invisible] = source.rgb[row:row+128][invisible]
        output[row:row+128] = quantized
    return Photo(output, source.alpha.copy() if source.alpha is not None else None,
                 source.orientation, {}), {'gamut_compressed_pixels': mapped_count,
                                            'spatial_operations': [], 'strip_rows': 128}


def _quantize_guard(original_bytes, result, preset):
    """Check protection after 8-bit quantization, where rounding can increase hue drift."""
    original = original_bytes.astype(np.float32)/255
    skin, blue, _ = masks(original)
    before = rgb_to_hsv(original)
    limits = np.where(skin, preset['skin_hue_limit_deg'], preset['blue_hue_limit_deg'])
    protected = skin | blue
    quantized = np.rint(np.clip(result, 0, 1)*255).astype(np.uint8)
    # No new near-endpoint channels where the input pixel had none.
    high_safe = original_bytes.max(axis=-1) < 254
    low_safe = original_bytes.min(axis=-1) > 1
    for _ in range(8):
        quantized[high_safe] = np.minimum(quantized[high_safe], 253)
        quantized[low_safe] = np.maximum(quantized[low_safe], 2)
        after = rgb_to_hsv(quantized.astype(np.float32)/255)
        drift = np.abs((after[..., 0]-before[..., 0]+.5) % 1-.5)*360
        bad = protected & (drift > limits+.5)
        if not bad.any():
            return quantized
        # Fall back toward original color rather than sacrifice protected hue to the look.
        result[bad] = original[bad]+.7*(result[bad]-original[bad])
        quantized[bad] = np.rint(np.clip(result[bad], 0, 1)*255).astype(np.uint8)
    quantized[bad] = original_bytes[bad]
    return quantized
