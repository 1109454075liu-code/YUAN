"""8-bit image IO with color management and unchanged stored pixel coordinates."""
from dataclasses import dataclass
from pathlib import Path
import hashlib
import io
import json
import numpy as np
from PIL import Image, ImageCms


@dataclass
class Photo:
    rgb: np.ndarray
    alpha: np.ndarray | None
    orientation: int
    metadata: dict


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def pixel_hash(photo):
    h = hashlib.sha256()
    h.update(str(photo.rgb.shape).encode('ascii'))
    h.update(photo.rgb.tobytes())
    if photo.alpha is not None:
        h.update(photo.alpha.tobytes())
    h.update(str(photo.orientation).encode('ascii'))
    return h.hexdigest()


def load_photo(path):
    path = Path(path)
    with Image.open(path) as image:
        if getattr(image, 'n_frames', 1) != 1:
            raise ValueError('Animated/multi-frame files are unsupported; supply one still image.')
        if image.mode not in ('RGB', 'RGBA', 'L', 'LA', 'P', 'CMYK'):
            raise ValueError(f'Unsupported {image.mode}: use an 8-bit sRGB JPEG/PNG/WebP. RAW/HDR/16-bit are not supported.')
        orientation = int(image.getexif().get(274, 1))
        if orientation not in range(1, 9):
            raise ValueError('Invalid EXIF orientation.')
        image.load()
        mode = image.mode
        alpha = None
        if 'A' in image.getbands() or 'transparency' in image.info:
            alpha = np.array(image.convert('RGBA').getchannel('A'), dtype=np.uint8)
        icc = image.info.get('icc_profile')
        if icc:
            try:
                profile = ImageCms.ImageCmsProfile(io.BytesIO(icc))
                cms_input = image if mode == 'CMYK' else image.convert('RGB')
                rgb = ImageCms.profileToProfile(cms_input, profile, ImageCms.createProfile('sRGB'),
                                               outputMode='RGB', renderingIntent=1)
            except Exception as exc:
                raise ValueError('Invalid/unsupported ICC profile; explicitly export an sRGB source first.') from exc
            color_management = 'embedded ICC converted to sRGB'
        else:
            if mode == 'CMYK':
                raise ValueError('Untagged CMYK is unsupported; export tagged sRGB first.')
            rgb = image.convert('RGB')
            color_management = 'untagged input assumed sRGB'
        data = np.array(rgb, dtype=np.uint8)
        stored = list(image.size)
    return Photo(data, alpha, orientation, {
        'name': path.name, 'file_sha256': sha256_file(path), 'stored_size': stored,
        'display_size': stored[::-1] if orientation >= 5 else stored,
        'exif_orientation': orientation, 'input_mode': mode,
        'color_management': color_management,
    })


def save_photo(photo, path):
    path = Path(path)
    if path.suffix.lower() not in ('.png', '.jpg', '.jpeg'):
        raise ValueError('Output must be PNG (recommended) or JPEG.')
    if photo.alpha is not None and path.suffix.lower() != '.png':
        raise ValueError('Use PNG to preserve the source alpha channel.')
    array = photo.rgb if photo.alpha is None else np.dstack((photo.rgb, photo.alpha))
    image = Image.fromarray(array)
    exif = Image.Exif()
    exif[274] = photo.orientation
    profile = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    path.parent.mkdir(parents=True, exist_ok=True)
    options = {'icc_profile': profile, 'exif': exif.tobytes()}
    if path.suffix.lower() in ('.jpg', '.jpeg'):
        options.update(quality=98, subsampling=0)
    image.save(path, **options)


def write_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
