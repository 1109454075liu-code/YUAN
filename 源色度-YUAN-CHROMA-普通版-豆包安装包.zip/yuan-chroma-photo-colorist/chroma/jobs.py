"""Portable daily jobs: prepare evidence, require Agent analysis, then render.

No style inference or semantic region inference happens in this module.
All region annotations use normalized, upright display coordinates.
"""
from contextlib import redirect_stdout
from io import StringIO
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace

import numpy as np
from PIL import Image, ImageOps

from .io import load_photo, save_photo, pixel_hash, sha256_file, write_json
from .stats import analyze
from .workflow import execute_style, load_style_model, STYLE_AXES


def _read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _inside(root, relative):
    if not isinstance(relative, str) or Path(relative).is_absolute():
        raise ValueError('Job paths must be relative to its directory.')
    target = (root / relative).resolve()
    if not target.is_relative_to(root.resolve()) or target == root.resolve():
        raise ValueError('Job path leaves the task directory.')
    return target


def _number(value, lo=0, hi=1):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not lo <= value <= hi:
        raise ValueError(f'Expected a finite number in {lo}..{hi}.')
    return value


def _boxes(boxes):
    if not isinstance(boxes, list):
        raise ValueError('Regions must be a list of normalized [x0,y0,x1,y1] boxes.')
    for box in boxes:
        if not isinstance(box, list) or len(box) != 4:
            raise ValueError('Each region requires four display coordinates.')
        for n in box:
            _number(n)
        if box[0] >= box[2] or box[1] >= box[3]:
            raise ValueError('Region must have positive width and height.')
    return boxes


def display_to_stored(box, orientation):
    """Inverse of all eight EXIF transforms; no image resampling."""
    _boxes([box])
    transforms = {
        1: lambda x,y: (x,y), 2: lambda x,y: (1-x,y),
        3: lambda x,y: (1-x,1-y), 4: lambda x,y: (x,1-y),
        5: lambda x,y: (y,x), 6: lambda x,y: (y,1-x),
        7: lambda x,y: (1-y,1-x), 8: lambda x,y: (1-y,x),
    }
    if orientation not in transforms:
        raise ValueError('Unsupported EXIF orientation.')
    x0,y0,x1,y1 = box
    corners = [transforms[orientation](x,y) for x in (x0,x1) for y in (y0,y1)]
    return [min(x for x,y in corners), min(y for x,y in corners),
            max(x for x,y in corners), max(y for x,y in corners)]


def _preview(photo, path):
    im = Image.fromarray(photo.rgb if photo.alpha is None else np.dstack((photo.rgb, photo.alpha)))
    exif = Image.Exif(); exif[274] = photo.orientation
    im.info['exif'] = exif.tobytes()
    im = ImageOps.exif_transpose(im)
    im.thumbnail((1200,1200))
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path)


def _decode(path, scratch):
    if path.suffix.lower() not in ('.heic', '.heif'):
        # Some user JPEGs carry a second, explicitly identified HDR gain map.
        # Extract only that format's base image, never guess a stereo/animation frame.
        with Image.open(path) as image:
            if image.format == 'MPO' and getattr(image,'n_frames',1) == 2 and image.mode == 'RGB':
                primary = image.copy()
                image.seek(1)
                xmp = image.info.get('xmp',b'')
                if isinstance(xmp,str):
                    xmp = xmp.encode('utf-8')
                if image.mode == 'L' and b'urn:com:apple:photo:2020:aux:hdrgainmap' in xmp:
                    options = {'exif':primary.getexif().tobytes()}
                    if primary.info.get('icc_profile'):
                        options['icc_profile'] = primary.info['icc_profile']
                    primary.save(scratch,**options)
                    photo = load_photo(scratch)
                    photo.metadata['auxiliary_hdr_gainmap_omitted'] = True
                    return photo, 'Explicit Apple HDR auxiliary gain-map JPEG: base SDR image only; auxiliary map not applied, original dimensions/orientation retained'
        return load_photo(path), 'Pillow color-managed 8-bit decode'
    if sys.platform != 'darwin' or not shutil.which('sips'):
        raise ValueError('HEIC needs macOS sips; on other systems export an SDR/sRGB PNG first.')
    try:
        run = subprocess.run(['sips', '-s', 'format', 'png', str(path), '--out', str(scratch)],
                             capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired as exc:
        raise ValueError('Local HEIC decode timed out; export an SDR/sRGB PNG first.') from exc
    if run.returncode != 0 or not scratch.exists():
        raise ValueError('Local HEIC decode failed; export an SDR/sRGB PNG or rerun with permitted system image access. '+run.stderr.strip())
    return load_photo(scratch), 'macOS sips decode, normalized to 8-bit SDR/sRGB; not RAW/HDR reconstruction'


def prepare_job(inputs, reference, directory, style_model=None, strength=1, freeze_style=False):
    _number(strength)
    if freeze_style and not style_model:
        raise ValueError('Freeze-style requires a previously analyzed style model.')
    destination = Path(directory).resolve()
    if destination.exists():
        raise ValueError('Choose a new job directory; existing jobs are never replaced.')
    originals = [Path(p).resolve(strict=True) for p in inputs]
    ref = Path(reference).resolve(strict=True)
    if not originals or len(originals)>999 or len(set(originals)) != len(originals) or ref in originals:
        raise ValueError('Supply distinct originals and a separate reference.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    scratch = Path(tempfile.mkdtemp(prefix='.chroma-prepare-', dir=destination.parent))
    try:
        ref_hash_before = sha256_file(ref)
        photo, method = _decode(ref, scratch/'ref-decoded.png')
        normalized_ref = ref.suffix.lower() in ('.heic','.heif') or photo.metadata.get('auxiliary_hdr_gainmap_omitted',False)
        ref_file = 'reference.png' if normalized_ref else 'reference'+ref.suffix.lower()
        if normalized_ref:
            save_photo(photo, scratch/ref_file)
        else:
            shutil.copyfile(ref, scratch/ref_file)
        normalized_reference = load_photo(scratch/ref_file)
        _preview(normalized_reference, scratch/'reference.preview.png')
        write_json(scratch/'reference.statistics.json', analyze(normalized_reference))
        model_file = 'style-model.json'
        if style_model:
            load_style_model(style_model, scratch/ref_file)
            shutil.copyfile(style_model, scratch/model_file)
        else:
            # Deliberately not a runnable model. The Agent must infer operators.
            write_json(scratch/'style-analysis.draft.json', {
                'reference_sha256': sha256_file(scratch/ref_file),
                'status': 'awaiting_agent_visual_style_analysis',
                'style_axes': {axis: {'description': None, 'confidence': None} for axis in STYLE_AXES},
                'visible_appearance': [], 'inferences': [], 'lighting_material_lens_uncertainty': [],
                'next': 'View reference, infer grading style, write a validated photographic-grading-style-model to style-model.json. No default operators are auto-filled.'})
        rows = []
        for index, original in enumerate(originals,1):
            key = f'{index:03d}'
            before = sha256_file(original)
            src, decode_method = _decode(original, scratch/f'{key}-decoded.png')
            image_file = f'inputs/{key}.png'; preview_file = f'previews/{key}.png'
            save_photo(src, scratch/image_file)
            normalized = load_photo(scratch/image_file)
            if pixel_hash(src) != pixel_hash(normalized):
                raise ValueError('Normalized working copy changed decoded pixels or orientation.')
            _preview(normalized, scratch/preview_file)
            stats_file = f'analysis/{key}.statistics.json'
            write_json(scratch/stats_file, analyze(normalized))
            review_file = f'analysis/{key}.review.json'
            write_json(scratch/review_file, {
                'schema_version': 1, 'source_pixel_sha256': pixel_hash(normalized),
                'coordinate_space': 'normalized_upright_display', 'reviewed': False,
                'reviewer': None, 'reason': None,
                'faces_display': [], 'skin_display': [], 'sky_display': [],
                'neutral_anchor_ROIs_display': [], 'white_balance_confidence': 0,
                'note': 'Agent must view this original and verify regions. Empty defaults do not mean absence of people/sky. No credible neutral anchor means confidence=0.'})
            if sha256_file(original) != before:
                raise ValueError('An original changed during job preparation.')
            rows.append({'id':key,'original_name':original.name,'original_path_at_prepare':str(original),
                         'original_sha256':before,'decode_method':decode_method,
                         'image':image_file,'image_sha256':sha256_file(scratch/image_file),
                         'pixel_sha256':pixel_hash(normalized),'orientation':normalized.orientation,
                         'stored_size':normalized.metadata['stored_size'],
                         'preview':preview_file,'statistics':stats_file,'review':review_file})
        if sha256_file(ref) != ref_hash_before:
            raise ValueError('Reference changed during job preparation.')
        job = {
            'schema_version':1,'workflow':'daily-reference-style-first-v1','strength':strength,
            'reference':{'image':ref_file,'sha256':sha256_file(scratch/ref_file),
                         'original_sha256':ref_hash_before,'original_name':ref.name,'decode_method':method,
                         'preview':'reference.preview.png','statistics':'reference.statistics.json'},
            'style_model':model_file,'sources':rows}
        if freeze_style:
            job['style_freeze'] = {
                'model_sha256':sha256_file(scratch/model_file),'reference_sha256':sha256_file(scratch/ref_file),
                'strength':strength,'renderer_sha256':sha256_file(Path(__file__).with_name('style_renderer.py'))}
        write_json(scratch/'job.json',job)
        (scratch/'AGENT-START.md').write_text(
            '# CHROMA 日常任务\n\n先查看参考图，分析调色风格，写入 style-model.json。已有同参考模型可复用。\n'
            '再逐张查看原图，填写 analysis/*.review.json，核对人物、皮肤、天空与可信中性取样。\n'
            '所有矩形都用正向显示图上的 0–1 坐标；程序自动换算到存储坐标。\n'
            'reviewed=true 表示 Agent 完成原图分析，不是用户认可成片。\n'
            '运行 python -m chroma run-job --job-dir 本目录；查看 results 与 summary.json。\n'
            '统计是辅助证据。新参考不能照抄已有风格控制量，程序不自动猜风格。\n'
            '没有可信中性色时保持取样为空、白平衡置信度为零。详见项目 references/daily-jobs.md。\n', encoding='utf-8')
        for p in scratch.glob('*-decoded.png'):
            p.unlink()
        scratch.rename(destination)
    except BaseException:
        shutil.rmtree(scratch, ignore_errors=True)
        raise
    return job_status(destination)


def _review(path, source):
    review = _read(path)
    if review.get('schema_version') != 1 or review.get('coordinate_space') != 'normalized_upright_display':
        raise ValueError('Source review must use schema 1 and upright display coordinates.')
    if review.get('source_pixel_sha256') != pixel_hash(source):
        raise ValueError('Source review belongs to another original.')
    if review.get('reviewed') is not True:
        raise ValueError('Agent must view and review the original before execution.')
    for key in ('reason','reviewer'):
        if not isinstance(review.get(key),str) or not review[key].strip():
            raise ValueError('Source review needs '+key)
    for key in ('faces_display','skin_display','sky_display','neutral_anchor_ROIs_display'):
        _boxes(review[key])
    _number(review['white_balance_confidence'])
    if review['white_balance_confidence'] > 0 and not review['neutral_anchor_ROIs_display']:
        raise ValueError('Nonzero white balance confidence requires reviewed neutral anchors.')
    return review


def _load_job(directory):
    root = Path(directory).resolve(strict=True)
    for name in ('job.json','execution.lock.json','run.json','summary.json'):
        _inside(root,name)
    job = _read(root/'job.json')
    if job.get('schema_version') != 1 or job.get('workflow') != 'daily-reference-style-first-v1':
        raise ValueError('Unsupported job schema.')
    _number(job['strength'])
    rows = job['sources']
    if not isinstance(rows,list) or not rows:
        raise ValueError('Job requires at least one source.')
    ids = [row['id'] for row in rows]
    if any(not isinstance(k,str) or len(k)!=3 or not k.isascii() or not k.isdigit() for k in ids) or len(set(ids))!=len(ids):
        raise ValueError('Source ids must be unique three-digit numbers.')
    for rel in [job['style_model'],job['reference']['image']]+[row[k] for row in rows for k in ('image','review')]:
        _inside(root,rel)
    return root,job


def _preflight(root,job):
    ref = _inside(root,job['reference']['image'])
    if sha256_file(ref) != job['reference']['sha256']:
        raise ValueError('Job reference changed; prepare a new job and analyze that reference.')
    model = _inside(root,job['style_model'])
    load_style_model(model,ref)
    freeze = job.get('style_freeze')
    if freeze is not None:
        actual = {'model_sha256':sha256_file(model),'reference_sha256':sha256_file(ref),'strength':job['strength'],
                  'renderer_sha256':sha256_file(Path(__file__).with_name('style_renderer.py'))}
        if freeze != actual:
            raise ValueError('Frozen style, strength, reference or renderer changed; this is not the same transfer trial.')
    checks = {job['reference']['image']:sha256_file(ref),job['style_model']:sha256_file(model)}
    reviewed = []
    for row in job['sources']:
        path = _inside(root,row['image']); src = load_photo(path)
        if sha256_file(path) != row['image_sha256'] or pixel_hash(src) != row['pixel_sha256']:
            raise ValueError('Working original changed: '+row['id'])
        if row['orientation'] != src.orientation or row['stored_size'] != src.metadata['stored_size']:
            raise ValueError('Source orientation or size metadata changed: '+row['id'])
        review_file = _inside(root,row['review'])
        reviewed.append(_review(review_file,src))
        checks[row['image']] = sha256_file(path); checks[row['review']] = sha256_file(review_file)
    lock = {'schema_version':1,'job_sha256':sha256_file(root/'job.json'),
            'renderer_sha256':sha256_file(Path(__file__).with_name('style_renderer.py')),'inputs':checks}
    return lock,reviewed


def _run_record(root,job):
    run = _read(root/'run.json') if (root/'run.json').exists() else {'schema_version':1,'completed':{}}
    if run.get('schema_version') != 1 or not isinstance(run.get('completed'),dict):
        raise ValueError('Invalid execution record.')
    if run['completed'] and not (root/'execution.lock.json').exists():
        raise ValueError('Completed job is missing its analysis lock; preserve results and prepare a new job.')
    if not set(run['completed']).issubset({row['id'] for row in job['sources']}):
        raise ValueError('Execution record contains unknown source ids.')
    for key,item in run['completed'].items():
        expected = {f'results/{key}'+s for s in ('.png','.plan.json','.report.json','.compare.png','.workflow.json')}
        expected.update(f'context/{key}-{k}.json' for k in ('faces','skin','context'))
        if set(item['artifact_sha256']) != expected:
            raise ValueError('Incomplete result verification record: '+key)
    return run


def _aesthetic_state(root,job,run):
    """Read explicit user feedback bound to the exact rendered results.

    An Agent records this only after the user's actual evaluation. Technical
    checks never create acceptance. Editing a model/result invalidates it.
    """
    path = _inside(root,'acceptance.json')
    if not path.exists():
        return 'awaiting_user_review'
    record = _read(path)
    if record.get('status') != 'accepted_by_user':
        return 'awaiting_user_review'
    if record.get('schema_version') != 1 or not isinstance(record.get('user_words'),str) or not record['user_words'].strip():
        raise ValueError('Acceptance requires recorded explicit user feedback.')
    if record.get('style_model_sha256') != sha256_file(_inside(root,job['style_model'])):
        raise ValueError('Acceptance belongs to another style model.')
    rows = record.get('results',[])
    expected = {row['id'] for row in job['sources']}
    if len(rows)!=len(expected) or {row['id'] for row in rows}!=expected or set(run['completed'])!=expected:
        raise ValueError('Acceptance must identify all completed sources exactly once.')
    for row in rows:
        for kind,suffix in (('output','.png'),('plan','.plan.json')):
            if row[kind+'_sha256'] != sha256_file(_inside(root,f'results/{row["id"]}'+suffix)):
                raise ValueError('Acceptance differs from the saved result or plan.')
    return 'accepted_by_user'


def job_status(directory):
    root,job = _load_job(directory)
    blockers = []
    try:
        lock,_ = _preflight(root,job)
        if (root/'execution.lock.json').exists() and _read(root/'execution.lock.json') != lock:
            blockers.append('Analysis or inputs changed after execution; create a new job for revisions.')
    except (ValueError,OSError,KeyError,TypeError) as exc:
        blockers.append(str(exc))
    run = _run_record(root,job)
    for key,item in run['completed'].items():
        for rel,digest in item['artifact_sha256'].items():
            path = _inside(root,rel)
            if not path.exists() or sha256_file(path) != digest:
                blockers.append('Completed result changed or missing: '+key)
                break
    for row in job['sources']:
        key = row['id']
        if key in run['completed']:
            continue
        pending = [f'results/{key}'+s for s in ('.png','.plan.json','.report.json','.compare.png','.workflow.json')]
        pending += [f'context/{key}-{k}.json' for k in ('faces','skin','context')]
        if any(_inside(root,p).exists() for p in pending):
            blockers.append('Untracked/partial files exist for '+key+'; preserve them and prepare a new job.')
    if blockers:
        state = 'awaiting_analysis_or_repair'
        aesthetic = 'awaiting_user_review'
    elif len(run['completed']) == len(job['sources']):
        aesthetic = _aesthetic_state(root,job,run)
        state = 'rendered_accepted_by_user' if aesthetic=='accepted_by_user' else 'rendered_awaiting_visual_review'
    else:
        state = 'ready_to_render'
        aesthetic = 'awaiting_user_review'
    return {'job_directory':str(root),'state':state,'originals':len(job['sources']),
            'completed':len(run['completed']),'blockers':blockers,
            'style_analysis':'Agent-authored model required; arbitrary new references supported',
            'aesthetic_status':aesthetic,'style_frozen':job.get('style_freeze') is not None}


def run_job(directory):
    root,job = _load_job(directory)
    if (root/'.agent-write.lock').exists():
        raise ValueError('Agent analysis submission is active; wait for it to finish before rendering.')
    lock,reviews = _preflight(root,job)  # All sources checked before any render.
    lock_path = root/'execution.lock.json'
    if lock_path.exists() and _read(lock_path) != lock:
        raise ValueError('Job changed after execution; prepare a new job for revised grading.')
    run_path = root/'run.json'
    run = _run_record(root,job)
    status = job_status(root)
    if status['blockers']:
        raise ValueError('; '.join(status['blockers']))
    # Preflight all destinations and avoid overwriting even incomplete output sets.
    suffixes = ('.png','.plan.json','.report.json','.compare.png','.workflow.json')
    for row in job['sources']:
        if row['id'] in run['completed']:
            continue
        paths = [f'results/{row["id"]}'+s for s in suffixes]
        paths += [f'context/{row["id"]}-{k}.json' for k in ('faces','skin','context')]
        if any(_inside(root,p).exists() for p in paths):
            raise ValueError('Untracked/partial results exist; keep them for inspection and prepare a new job.')
    if not lock_path.exists():
        write_json(lock_path,lock)
    for row,review in zip(job['sources'],reviews):
        key = row['id']
        if key in run['completed']:
            continue
        transform = lambda boxes: [display_to_stored(b,row['orientation']) for b in boxes]
        common = {'source_pixel_sha256':row['pixel_sha256']}
        paths = {k:_inside(root,f'context/{key}-{k}.json') for k in ('faces','skin','context')}
        write_json(paths['faces'],{**common,'regions':transform(review['faces_display'])})
        write_json(paths['skin'],{**common,'regions':transform(review['skin_display'])})
        write_json(paths['context'],{**common,
            'neutral_anchor_ROIs_display':review['neutral_anchor_ROIs_display'],
            'white_balance_confidence':review['white_balance_confidence'],
            'sky_ROIs_stored':transform(review['sky_display']),'reason':review['reason']})
        output = _inside(root,f'results/{key}.png')
        args = SimpleNamespace(command='grade-style',input=str(_inside(root,row['image'])),
            style_model=str(_inside(root,job['style_model'])),reference=str(_inside(root,job['reference']['image'])),
            faces=str(paths['faces']),skin_scope=str(paths['skin']),context=str(paths['context']),
            strength=job['strength'],output=str(output))
        with redirect_stdout(StringIO()):
            code = execute_style(args)
        artifacts = [f'results/{key}'+s for s in suffixes]+[f'context/{key}-{k}.json' for k in paths]
        report = _read(output.with_suffix('.report.json'))
        run['completed'][key] = {'original_name':row['original_name'],
            'exit_code':code,'quality_status':report['status'],
            'issues':[name for name,passed in report['checks'].items() if not passed],
            'output':f'results/{key}.png','comparison':f'results/{key}.compare.png',
            'artifact_sha256':{p:sha256_file(_inside(root,p)) for p in artifacts}}
        write_json(run_path,run)
    aesthetic = _aesthetic_state(root,job,run)
    summary = {'schema_version':1,'workflow':'daily-reference-style-first-v1',
        'state':'rendered_accepted_by_user' if aesthetic=='accepted_by_user' else 'rendered_awaiting_visual_review',
        'aesthetic_status':aesthetic,
        'sources':len(job['sources']),'completed':len(run['completed']),
        'technical_issues':sum(bool(v['issues']) for v in run['completed'].values()),
        'style_model_sha256':lock['inputs'][job['style_model']],
        'style_frozen':job.get('style_freeze') is not None,
        'results':run['completed'],
        'limits':['Agent analysis is required for new references and originals.',
                  'Geometry unchanged; colors may change. Reference lighting cannot be reconstructed.']}
    write_json(root/'summary.json',summary)
    return summary, 3 if summary['technical_issues'] else 0
