"""Observable quality metrics, with architecture guarantees kept separate from proxies."""
import hashlib
import json
import platform
import numpy as np
import PIL
from PIL import Image, ImageDraw, ImageOps
from . import __version__
from .color import rgb_to_hsv, rgb_to_lab, masks
from .io import pixel_hash
from .stats import sample_pixels, describe, distance


def clipping(photo):
    high, low, pixels = 0, 0, 0
    for row in range(0, photo.rgb.shape[0], 128):
        rgb = photo.rgb[row:row+128]
        valid = np.ones(rgb.shape[:2], dtype=bool) if photo.alpha is None else photo.alpha[row:row+128] > 0
        pixels += int(valid.sum())
        high += int(((rgb.max(axis=-1) >= 254) & valid).sum())
        low += int(((rgb.min(axis=-1) <= 1) & valid).sum())
    sample = sample_pixels(photo)
    luma = sample @ np.array([.2126, .7152, .0722])
    return {'any_channel_high_fraction': high/max(pixels, 1),
            'any_channel_low_fraction': low/max(pixels, 1),
            'near_white_luma_fraction_sampled': float((luma >= .98).mean()),
            'note': 'Channel extremes can be legitimate colored objects, not necessarily lost exposure.'}


def _gradient_proxy(source, result):
    # QA-only thumbnails; rendering itself never resamples.
    images = []
    for p in (source, result):
        im = Image.fromarray(p.rgb)
        im.thumbnail((640, 640))
        a = np.asarray(im, dtype=np.float32)/255
        l = a @ np.array([.2126, .7152, .0722])
        dy, dx = np.gradient(l) if min(l.shape) >= 2 else (np.zeros_like(l), np.zeros_like(l))
        images.append(np.stack((dx, dy), axis=-1).reshape(-1))
    a, b = images
    if np.std(a) < 1e-8 or np.std(b) < 1e-8:
        return None
    return float(np.corrcoef(a, b)[0, 1])


def _hue_report(source, result):
    # Use matching coordinates and visible pixels; exclude low saturation where hue is unstable.
    n = source.rgb.shape[0]*source.rgb.shape[1]
    stride = max(1, int(np.ceil(n/60000)))
    a = source.rgb.reshape(-1, 3)[::stride].astype(np.float32)/255
    b = result.rgb.reshape(-1, 3)[::stride].astype(np.float32)/255
    skin, blue, _ = masks(a)
    ha, hb = rgb_to_hsv(a), rgb_to_hsv(b)
    visible = np.ones(len(a), dtype=bool) if source.alpha is None else source.alpha.reshape(-1)[::stride] > 0
    drift = np.abs((hb[:, 0]-ha[:, 0]+.5) % 1-.5)*360
    report = {}
    for name, mask in (('skin_like', skin), ('blue_like', blue)):
        mask &= visible & (ha[:, 1] > .20) & (hb[:, 1] > .10)
        values = drift[mask]
        report[name] = {'samples': int(mask.sum()),
                        'hue_shift_p95_deg': float(np.percentile(values, 95)) if len(values) else None,
                        'hue_shift_max_deg': float(values.max()) if len(values) else None}
    return report


def edit_magnitude(source, result):
    """Measure same-coordinate color change; magnitude is not aesthetic quality."""
    flat_source, flat_result = source.rgb.reshape(-1, 3), result.rgb.reshape(-1, 3)
    stride = max(1, int(np.ceil(len(flat_source)/60000)))
    indices = np.arange(0, len(flat_source), stride)
    if source.alpha is not None:
        indices = indices[source.alpha.reshape(-1)[indices] > 0]
        if not len(indices):
            indices = np.flatnonzero(source.alpha.reshape(-1) > 0)
            indices = indices[::max(1, int(np.ceil(len(indices)/60000)))]
    a, b = flat_source[indices], flat_result[indices]
    delta = np.linalg.norm(rgb_to_lab(a.astype(np.float32)/255)-rgb_to_lab(b.astype(np.float32)/255), axis=-1)
    return {'sample_count': len(indices), 'decoded_RGB_changed_fraction': float(np.any(a != b, axis=-1).mean()),
            'delta_E76_mean': float(delta.mean()), 'delta_E76_p50': float(np.percentile(delta, 50)),
            'delta_E76_p95': float(np.percentile(delta, 95)),
            'fraction_delta_E76_above_2': float((delta > 2).mean()),
            'interpretation': 'D65 Lab same-coordinate difference measures editing magnitude, not style accuracy or a universal visibility threshold.'}


def make_report(source, saved, plan, diagnostics, mask=None):
    source_stats, output_stats = describe(sample_pixels(source)), describe(sample_pixels(saved))
    before_clip, after_clip = clipping(source), clipping(saved)
    size_equal = source.rgb.shape == saved.rgb.shape
    alpha_equal = ((source.alpha is None and saved.alpha is None) or
                   (source.alpha is not None and saved.alpha is not None and np.array_equal(source.alpha, saved.alpha)))
    protected_exact = None if mask is None else bool(np.array_equal(source.rgb[mask == 255], saved.rgb[mask == 255]))
    encoding_lossless = saved.metadata.get('name', '').lower().endswith('.png')
    issues, warnings = [], []
    if not size_equal or source.orientation != saved.orientation:
        issues.append('Stored dimensions or EXIF orientation changed.')
    if not alpha_equal:
        issues.append('Alpha channel changed.')
    if protected_exact is False:
        (issues if encoding_lossless else warnings).append('Protected pixels differ after encoding; JPEG is lossy.')
    new_high = after_clip['any_channel_high_fraction']-before_clip['any_channel_high_fraction']
    new_white = after_clip['near_white_luma_fraction_sampled']-before_clip['near_white_luma_fraction_sampled']
    if new_high > .005:
        issues.append('New near-clipped channels exceed 0.5% of visible pixels.')
    if new_white > .001:
        issues.append('New near-white highlights exceed 0.1% of sampled visible pixels.')
    gradient = _gradient_proxy(source, saved)
    if gradient is not None and gradient < .85:
        warnings.append('Luminance gradient correlation is below 0.85; review detail/contrast visually.')
    if not encoding_lossless:
        warnings.append('JPEG encoding changes texture and pixels; use PNG for lossless graded output.')
    hue_report = _hue_report(source, saved)
    magnitude = edit_magnitude(source, saved)
    if plan['strength'] > 0 and (magnitude['delta_E76_mean'] < 1 or magnitude['decoded_RGB_changed_fraction'] < .005):
        warnings.append('Measured color change is small. Review the comparison; the source may already fit, a mask may freeze it, or a stronger preset may be needed.')
    for region, key in (('skin_like', 'skin_hue_limit_deg'), ('blue_like', 'blue_hue_limit_deg')):
        drift = hue_report[region]['hue_shift_max_deg']
        if drift is not None and drift > plan['preset'][key] + .501:
            issues.append(f'{region} hue drift exceeds preset limit plus 8-bit rounding allowance.')
    if 'assumed' in source.metadata['color_management']:
        warnings.append('Untagged source was assumed sRGB.')
    warnings.append('Skin/blue protection uses color proxies; verify faces, sky and text visually or use a protect mask.')
    reference_distance = None
    if plan['reference']:
        ref = plan['reference']['statistics']
        before, after = distance(source_stats, ref), distance(output_stats, ref)
        improvement = before['weighted_summary_distance']-after['weighted_summary_distance']
        reference_distance = {'before': before, 'after': after, 'improvement_positive_is_closer': improvement,
                              'metric': '0.25*L quantile MAE + 0.60*ab mean distance + 0.15*ab std distance (D65 Lab)',
                              'interpretation': 'Scene composition affects statistics. This is not a perceptual style score or physical-lighting measurement.'}
        if improvement < 0:
            warnings.append('Global reference statistics became less similar; constraints/preset can outweigh matching. Lower preset strength or try a more comparable reference.')
    parameters = json.dumps(plan, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')
    return {'schema_version': 1, 'status': 'needs_review' if issues else 'passed_with_notes',
            'issues': issues, 'warnings': warnings,
            'input': source.metadata, 'output': saved.metadata,
            'preservation': {'stored_dimensions_equal': size_equal,
                             'orientation_equal': source.orientation == saved.orientation,
                             'alpha_equal': alpha_equal, 'fully_protected_pixels_exact': protected_exact,
                             'geometry': 'Guaranteed by same-coordinate color processing, zero spatial transforms; not a learned content-detection verdict.',
                             'luminance_gradient_correlation_QA_proxy': gradient,
                             'original_file_untouched': True,
                             'pixel_values_unchanged': bool(np.array_equal(source.rgb, saved.rgb)),
                             'grain_changes_microtexture': plan['grain'] > 0 and plan['strength'] > 0},
            'reproducibility': {'input_normalized_pixel_sha256': pixel_hash(source),
                                'output_normalized_pixel_sha256': pixel_hash(saved),
                                'plan_sha256': hashlib.sha256(parameters).hexdigest(),
                                'seed': plan['seed'], 'engine_version': __version__,
                                'environment': {'python': platform.python_version(), 'numpy': np.__version__, 'pillow': PIL.__version__},
                                'scope': 'Same source, plan, mask, engine and dependency versions reproduce PNG decoded pixels; JPEG/files/other platforms are not promised byte-identical.'},
            'clipping': {'before': before_clip, 'after': after_clip, 'new_high_channel_fraction': new_high,
                         'new_near_white_fraction_sampled': new_white},
            'color_protection': hue_report,
            'edit_magnitude': magnitude,
            'statistics': {'before': source_stats, 'after': output_stats},
            'reference_match': reference_distance, 'execution': diagnostics,
            'limits': ['8-bit display-referred workflow; no RAW reconstruction or lost highlight recovery.',
                       'Reference cannot reproduce sun direction, physical lighting or new shadows.',
                       'Strict content fidelity preserves coordinates and objects while permitting changed colors; complete pixel identity only occurs at strength zero on normalized lossless output.']}


def comparison(source, result, path, reference=None):
    photos = [('ORIGINAL', source), ('CHROMA', result)]
    if reference:
        photos.append(('REFERENCE', reference))
    panel_width, panel_height, margin = 480, 640, 24
    canvas = Image.new('RGB', (len(photos)*panel_width+(len(photos)+1)*margin, panel_height+120), '#131917')
    draw = ImageDraw.Draw(canvas)
    for index, (title, photo) in enumerate(photos):
        x = margin+index*(panel_width+margin)
        im = Image.fromarray(photo.rgb)
        exif = im.getexif()
        exif[274] = photo.orientation
        im.info['exif'] = exif.tobytes()
        im = ImageOps.exif_transpose(im)
        im.thumbnail((panel_width, panel_height))
        canvas.paste(im, (x+(panel_width-im.width)//2, 70+(panel_height-im.height)//2))
        draw.text((x, 28), title, fill='#e8e8db')
    draw.text((margin, panel_height+90), f'CHROMA {__version__} | Same geometry, new color expression | Preview resized; output retains original dimensions', fill='#9baa9a')
    canvas.save(path)
