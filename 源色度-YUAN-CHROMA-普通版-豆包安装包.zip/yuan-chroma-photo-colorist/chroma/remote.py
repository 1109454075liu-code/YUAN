"""Pilot HTTP bridge: host Agent infers style, this service executes pixels.

No public deployment, model calls, URL fetching or accounts are created here.
"""
import argparse
import base64
import binascii
from contextlib import redirect_stdout
import hashlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from io import StringIO
import json
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import threading
import time
from urllib.parse import urlsplit
import uuid
from PIL import Image

from .agent import agent_start,agent_request,build_request,submit_analysis
from .io import write_json,sha256_file
from .jobs import job_status,run_job

MAX_BODY=64*1024*1024
MAX_IMAGE=20*1024*1024
MAX_PIXELS=32_000_000


class ApiError(ValueError):
    def __init__(self,status,message):
        self.status=status
        super().__init__(message)


def digest(value):return hashlib.sha256(value.encode()).hexdigest()


class PilotService:
    def __init__(self,directory,token,max_jobs=20):
        if not isinstance(token,str) or len(token)<24:
            raise ValueError('Set CHROMA_SERVICE_TOKEN to a random token of at least 24 characters. Do not include it in shared packages.')
        self.directory=Path(directory).resolve();self.directory.mkdir(parents=True,exist_ok=True)
        self.token=token;self.max_jobs=max_jobs
        self.global_lock=threading.RLock();self.locks={};self.active=set();self.failures={}

    def authorized(self,header):
        return isinstance(header,str) and secrets.compare_digest(header,'Bearer '+self.token)

    def root(self,key,job_key):
        if not re.fullmatch('[0-9a-f]{32}',key):raise ApiError(404,'Unknown task')
        folder=self.directory/key
        if not folder.is_dir():raise ApiError(404,'Unknown task')
        access=json.loads((folder/'access.json').read_text(encoding='utf-8'))
        if not isinstance(job_key,str) or not secrets.compare_digest(access['job_key_sha256'],digest(job_key)):
            raise ApiError(403,'This task requires its own X-Chroma-Job-Key')
        return folder

    def _image(self,photo,path):
        if not isinstance(photo,dict) or set(photo)!={'name','data_base64'}:
            raise ApiError(400,'Each photo needs name and data_base64')
        name=photo['name'];data=photo['data_base64']
        if not isinstance(name,str) or not name or len(name)>200 or any(c in name for c in '/\\:\x00') or name in ('.','..'):
            raise ApiError(400,'Use a simple photo filename, not a path or URL')
        suffix=Path(name).suffix.lower()
        if suffix not in ('.png','.jpg','.jpeg'):raise ApiError(400,'Pilot remote input supports PNG/JPEG; export HEIC first')
        if not isinstance(data,str) or len(data)>MAX_IMAGE*4//3+8:
            raise ApiError(413,'Image exceeds pilot limit')
        try:raw=base64.b64decode(data,validate=True)
        except (ValueError,binascii.Error):raise ApiError(400,'Invalid image base64') from None
        if not raw or len(raw)>MAX_IMAGE:raise ApiError(413,'Image exceeds pilot limit')
        file=path.with_suffix(suffix);file.write_bytes(raw)
        try:
            with Image.open(file) as im:
                if im.format not in ('PNG','JPEG','MPO') or im.width*im.height>MAX_PIXELS:
                    raise ApiError(400,'Unsupported image container or dimensions')
                im.verify()
        except (OSError,Image.DecompressionBombError) as exc:
            raise ApiError(400,'Invalid or oversized image') from None
        return file

    def create(self,data):
        if not isinstance(data,dict) or set(data)!={'originals','reference','strength'}:
            raise ApiError(400,'Expected originals, reference and strength')
        photos=data['originals'];strength=data['strength']
        if not isinstance(photos,list) or not 1<=len(photos)<=3:
            raise ApiError(400,'Pilot task needs 1..3 originals and one separate reference')
        if type(strength) not in (int,float) or not math.isfinite(strength) or not 0<=strength<=1:
            raise ApiError(400,'Strength must be finite in 0..1')
        with self.global_lock:
            if len([p for p in self.directory.iterdir() if p.is_dir()])>=self.max_jobs:
                raise ApiError(429,'Pilot task storage limit reached; owner must archive or remove old jobs')
            key=uuid.uuid4().hex;folder=self.directory/key;folder.mkdir()
        try:
            incoming=folder/'uploads';incoming.mkdir()
            originals=[self._image(p,incoming/f'original-{i:03}') for i,p in enumerate(photos,1)]
            reference=self._image(data['reference'],incoming/'reference')
            agent_start(originals,reference,folder/'job',strength=strength)
            job_key=secrets.token_urlsafe(32)
            write_json(folder/'access.json',{'job_key_sha256':digest(job_key),'created_unix':time.time()})
            self.locks[key]=threading.RLock()
            return {'job_id':key,'job_key':job_key,'stage':'reference_style',
                'next':f'/v1/jobs/{key}/request','aesthetic_status':'awaiting_user_review'}
        except Exception:
            shutil.rmtree(folder)
            raise

    def request(self,key,job_key):
        root=self.root(key,job_key)
        with self.global_lock:
            if key in self.active:raise ApiError(409,'Task is rendering')
        _,value=build_request(root/'job')
        # Response contains only stage data and inline upright previews; never
        # server local paths or original user directory metadata.
        value=dict(value);images=[]
        for item in value['images']:
            file=root/'job'/item['preview']
            images.append({k:v for k,v in item.items() if k!='preview'}|{
                'media_type':'image/png','data_base64':base64.b64encode(file.read_bytes()).decode()})
        value['images']=images
        value['transport_note']='request_sha256 still binds the original local evidence; inline previews are the corresponding bytes.'
        return value

    def status(self,key,job_key):
        root=self.root(key,job_key)
        with self.global_lock:
            if key in self.active:return {'job_id':key,'state':'rendering','aesthetic_status':'awaiting_user_review'}
        status=job_status(root/'job');status.pop('job_directory',None)
        if key in self.failures:
            status['state']='execution_failed';status['failure']='Execution failed; preserve evidence and inspect server-side logs or create a new task.'
        status['job_id']=key
        if status['completed']:
            run=json.loads((root/'job/run.json').read_text(encoding='utf-8'))
            status['results']=[{'id':i,'quality_status':r['quality_status'],
              'output':f'/v1/jobs/{key}/artifacts/{i}.png',
              'comparison':f'/v1/jobs/{key}/artifacts/{i}.compare.png',
              'report':f'/v1/jobs/{key}/artifacts/{i}.report.json',
              'plan':f'/v1/jobs/{key}/artifacts/{i}.plan.json'} for i,r in run['completed'].items()]
        return status

    def _render(self,key,root):
        try:
            with self.locks[key]:run_job(root/'job')
        except Exception:
            # Persist failure state without exposing internal filenames/tokens.
            write_json(root/'service-error.json',{'status':'execution_failed','action':'Inspect original task evidence locally; no automatic retry.'})
            self.failures[key]=True
        finally:
            with self.global_lock:self.active.discard(key)

    def submit(self,key,job_key,data):
        root=self.root(key,job_key)
        with self.global_lock:
            lock=self.locks.setdefault(key,threading.RLock())
            if key in self.active:raise ApiError(409,'Task is already rendering')
            if self.active:raise ApiError(429,'Pilot renderer is busy; retry after the current task completes')
            # Serialize entire stage commit and worker launch per trusted pilot.
            with lock:
                response,code=submit_analysis(root/'job',data,render=False)
                if response.get('stage')=='source_adaptation':
                    return {'job_id':key,'stage':'source_adaptation','next':f'/v1/jobs/{key}/request'},200
                self.active.add(key)
                threading.Thread(target=self._render,args=(key,root),daemon=True).start()
        return {'job_id':key,'state':'rendering','next':f'/v1/jobs/{key}','aesthetic_status':'awaiting_user_review'},202

    def artifact(self,key,job_key,name):
        root=self.root(key,job_key)
        if not re.fullmatch(r'[0-9]{3}\.(?:png|compare\.png|plan\.json|report\.json|workflow\.json)',name):
            raise ApiError(404,'Unknown artifact')
        source=name[:3];run=root/'job/run.json'
        if not run.exists():raise ApiError(409,'Results are not ready')
        record=json.loads(run.read_text(encoding='utf-8'))['completed'].get(source)
        relative='results/'+name
        if not record or relative not in record['artifact_sha256']:raise ApiError(404,'Unknown or unfinished artifact')
        file=root/'job'/relative
        if not file.exists() or sha256_file(file)!=record['artifact_sha256'][relative]:
            raise ApiError(409,'Result changed; preserve task for inspection')
        return file,'image/png' if name.endswith('.png') else 'application/json; charset=utf-8'


class Handler(BaseHTTPRequestHandler):
    server_version='CHROMA-Pilot'
    def log_message(self,*args):pass # Avoid recording photo paths, access keys or bodies.
    def _json(self,code,data):
        raw=json.dumps(data,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
    def _body(self):
        if self.headers.get('Transfer-Encoding'):raise ApiError(400,'Chunked request bodies are unsupported')
        if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':raise ApiError(415,'Use application/json')
        try:n=int(self.headers.get('Content-Length','0'))
        except ValueError:raise ApiError(400,'Invalid content length') from None
        if not 0<n<=MAX_BODY:raise ApiError(413,'Body exceeds pilot limit or is empty')
        raw=self.rfile.read(n)
        if len(raw)!=n:raise ApiError(400,'Incomplete body')
        try:return json.loads(raw,parse_constant=lambda v:(_ for _ in ()).throw(ValueError('Non-finite JSON')))
        except (json.JSONDecodeError,UnicodeDecodeError,ValueError):raise ApiError(400,'Invalid JSON') from None
    def setup(self):
        super().setup();self.connection.settimeout(30)
    def dispatch(self):
        route=urlsplit(self.path)
        if route.query:raise ApiError(400,'Credentials/parameters must not be put into URLs')
        if self.command=='GET' and route.path=='/health':return self._json(200,{'status':'ok','mode':'trusted_pilot','image_processing':'deterministic_pixels'})
        api=self.server.api
        if not api.authorized(self.headers.get('Authorization')):raise ApiError(401,'Bearer authorization required')
        if self.command=='POST' and route.path=='/v1/jobs':return self._json(201,api.create(self._body()))
        m=re.fullmatch(r'/v1/jobs/([0-9a-f]{32})(?:/(request|analysis|artifacts/([^/]+)))?',route.path)
        if not m:raise ApiError(404,'Unknown endpoint')
        key,operation,artifact=m.groups();job_key=self.headers.get('X-Chroma-Job-Key')
        if self.command=='GET' and operation is None:return self._json(200,api.status(key,job_key))
        if self.command=='GET' and operation=='request':return self._json(200,api.request(key,job_key))
        if self.command=='POST' and operation=='analysis':
            value,code=api.submit(key,job_key,self._body());return self._json(code,value)
        if self.command=='GET' and artifact:
            file,kind=api.artifact(key,job_key,artifact)
            self.send_response(200);self.send_header('Content-Type',kind)
            self.send_header('Content-Length',str(file.stat().st_size));self.send_header('Cache-Control','no-store');self.end_headers()
            with file.open('rb') as stream:shutil.copyfileobj(stream,self.wfile)
            return
        raise ApiError(405,'Unsupported method')
    def handle_api(self):
        try:self.dispatch()
        except ApiError as exc:self._json(exc.status,{'error':str(exc)})
        except (ValueError,KeyError,TypeError,OSError):self._json(400,{'error':'Task input/analysis failed validation. Correct the current stage or create a new task.'})
        except Exception:self._json(500,{'error':'Service failed; preserve task and inspect local evidence.'})
    def do_GET(self):self.handle_api()
    def do_POST(self):self.handle_api()


def make_server(directory,token,host='127.0.0.1',port=0):
    api=PilotService(directory,token)
    server=ThreadingHTTPServer((host,port),Handler);server.api=api
    return server


def main(argv=None):
    p=argparse.ArgumentParser(description='CHROMA trusted-pilot pixel service; no vision model or public deployment')
    p.add_argument('--data-dir',required=True);p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765)
    args=p.parse_args(argv)
    token=os.environ.get('CHROMA_SERVICE_TOKEN')
    try:server=make_server(args.data_dir,token,args.host,args.port)
    except (ValueError,OSError) as exc:raise SystemExit(str(exc))
    print(json.dumps({'status':'listening','host':args.host,'port':server.server_address[1],
        'mode':'trusted_pilot','limits':'Not production multi-tenant hosting; use authenticated HTTPS behind a gateway for external deployment.'}))
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
