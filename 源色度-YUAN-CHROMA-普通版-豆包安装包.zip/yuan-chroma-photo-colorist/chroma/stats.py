import numpy as np
from .color import rgb_to_lab, rgb_to_hsv, masks

QUANTILES = [1, 10, 25, 50, 75, 90, 99]


def sample_pixels(photo, maximum=60000):
    flat = photo.rgb.reshape(-1, 3)
    step = max(1, int(np.ceil(len(flat)/maximum)))
    sampled = flat[::step].astype(np.float32)/255
    if photo.alpha is not None:
        sampled = sampled[photo.alpha.reshape(-1)[::step] > 0]
        if not len(sampled):
            # Sparse transparency may put every visible pixel between regular sample positions.
            visible = np.flatnonzero(photo.alpha.reshape(-1) > 0)
            if len(visible):
                sampled = flat[visible[::max(1, int(np.ceil(len(visible)/maximum)))]].astype(np.float32)/255
    if not len(sampled):
        raise ValueError('No visible pixels to analyze.')
    return sampled


def describe(rgb):
    lab = rgb_to_lab(rgb)
    l = lab[..., 0]
    skin, blue, green = masks(rgb)
    bands = []
    for lo, hi in ((0, 35), (35, 70), (70, 101)):
        selected = lab[(l >= lo) & (l < hi)]
        bands.append({'range_L': [lo, hi], 'count': len(selected),
                      'ab_mean': selected[:, 1:].mean(axis=0).tolist() if len(selected) else [0., 0.],
                      'ab_std': selected[:, 1:].std(axis=0).tolist() if len(selected) else [0., 0.]})
    return {'sample_count': len(rgb), 'L_percentiles': np.percentile(l, QUANTILES).tolist(),
            'L_mean': float(l.mean()), 'L_std': float(l.std()),
            'ab_mean': lab[:, 1:].mean(axis=0).tolist(), 'ab_std': lab[:, 1:].std(axis=0).tolist(),
            'saturation_mean': float(rgb_to_hsv(rgb)[:, 1].mean()),
            'color_proxy_coverage': {'skin_like': float(skin.mean()), 'blue_like': float(blue.mean()),
                                     'green_like': float((green > .5).mean())},
            'tone_bands': bands}


def analyze(photo):
    return {**photo.metadata, 'statistics': describe(sample_pixels(photo))}


def distance(a, b):
    """Summary distance in Lab units; no correspondence or style-perception claim."""
    luminance = float(np.mean(np.abs(np.array(a['L_percentiles'])-b['L_percentiles'])))
    chroma_mean = float(np.linalg.norm(np.array(a['ab_mean'])-b['ab_mean']))
    chroma_spread = float(np.linalg.norm(np.array(a['ab_std'])-b['ab_std']))
    return {'L_quantile_MAE': luminance, 'ab_mean_distance': chroma_mean,
            'ab_std_distance': chroma_spread,
            'weighted_summary_distance': luminance*.25 + chroma_mean*.6 + chroma_spread*.15}
