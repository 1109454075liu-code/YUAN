"""Reusable reference-color statistics, distinct from a source-bound replay plan."""
import copy
import json
from pathlib import Path
import numpy as np
from .stats import describe, sample_pixels


def _array(value, shape, lo, hi, label):
    array = np.asarray(value, dtype=float)
    if array.shape != shape or not np.isfinite(array).all() or (array < lo).any() or (array > hi).any():
        raise ValueError(f'Invalid style profile {label}.')
    return array


def validate_profile(profile):
    keys = {'schema_version', 'profile_type', 'color_space', 'name', 'source', 'statistics'}
    if (not isinstance(profile, dict) or set(profile) != keys or profile['schema_version'] != 1 or
            profile['profile_type'] != 'bounded-reference-statistics' or profile['color_space'] != 'CIELAB-D65'):
        raise ValueError('Unsupported style profile schema or color space.')
    if not isinstance(profile['name'], str) or not 1 <= len(profile['name']) <= 120:
        raise ValueError('Style profile name must have 1..120 characters.')
    if not isinstance(profile['source'], dict):
        raise ValueError('Style profile source metadata must be an object.')
    stats = profile['statistics']
    keys = {'sample_count', 'L_percentiles', 'L_mean', 'L_std', 'ab_mean', 'ab_std',
            'saturation_mean', 'color_proxy_coverage', 'tone_bands'}
    if not isinstance(stats, dict) or set(stats) != keys:
        raise ValueError('Style profile statistics have missing or unsupported fields.')
    if isinstance(stats['sample_count'], bool) or not isinstance(stats['sample_count'], int) or stats['sample_count'] < 1:
        raise ValueError('Style profile sample count must be positive.')
    quantiles = _array(stats['L_percentiles'], (7,), 0, 100.001, 'L_percentiles')
    if (np.diff(quantiles) < 0).any():
        raise ValueError('Style profile L percentiles must be ordered.')
    for key, lo, hi in (('L_mean', 0, 100.001), ('L_std', 0, 100), ('saturation_mean', 0, 1)):
        _array(stats[key], (), lo, hi, key)
    _array(stats['ab_mean'], (2,), -128, 128, 'ab_mean')
    _array(stats['ab_std'], (2,), 0, 128, 'ab_std')
    coverage = stats['color_proxy_coverage']
    if not isinstance(coverage, dict) or set(coverage) != {'skin_like', 'blue_like', 'green_like'}:
        raise ValueError('Style profile color proxy coverage must contain supported keys.')
    for key, value in coverage.items():
        _array(value, (), 0, 1, key)
    bands = stats['tone_bands']
    if not isinstance(bands, list) or len(bands) != 3:
        raise ValueError('Style profile requires three tone bands.')
    total = 0
    for band, limits in zip(bands, [[0, 35], [35, 70], [70, 101]]):
        if not isinstance(band, dict) or set(band) != {'range_L', 'count', 'ab_mean', 'ab_std'} or band['range_L'] != limits:
            raise ValueError('Invalid style profile tone bands.')
        count = band['count']
        if isinstance(count, bool) or not isinstance(count, int) or count < 0:
            raise ValueError('Invalid style profile tone count.')
        total += count
        _array(band['ab_mean'], (2,), -128, 128, 'band ab_mean')
        _array(band['ab_std'], (2,), 0, 128, 'band ab_std')
    if total != stats['sample_count']:
        raise ValueError('Style profile tone counts do not match the sample count.')
    return profile


def extract_profile(reference, name='Reference color style'):
    profile = {'schema_version': 1, 'profile_type': 'bounded-reference-statistics',
               'color_space': 'CIELAB-D65', 'name': name,
               'source': copy.deepcopy(reference.metadata), 'statistics': describe(sample_pixels(reference))}
    return validate_profile(profile)


def load_profile(path):
    return validate_profile(json.loads(Path(path).read_text(encoding='utf-8')))
