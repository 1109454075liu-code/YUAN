"""Execute a fitted photography style, preserving every source pixel coordinate."""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps
from chroma.color import rgb_to_lab, rgb_to_hsv, hsv_to_rgb, gamut_map, smooth
from chroma.io import load_photo, save_photo, Photo, pixel_hash, sha256_file, write_json
from chroma.stats import sample_pixels, describe
from chroma.quality import clipping, edit_magnitude, _gradient_proxy


def validate_model(model):
    if model.get('profile_type')!='photographic-grading-style-model' or model.get('schema_version')!=1:
        raise ValueError('Unsupported style model schema.')
    op = model['operators']; curve = np.asarray(op['tone_curve_L'],dtype=float)
    if curve.ndim!=2 or curve.shape[1]!=2 or len(curve)<2 or not np.isfinite(curve).all():
        raise ValueError('Tone curve requires finite [input L, output L] points.')
    if curve[0,0]!=0 or curve[-1,0]!=100 or np.any(curve<0) or np.any(curve>100):
        raise ValueError('Tone curve must span 0..100 and stay within 0..100.')
    if np.any(np.diff(curve[:,0])<=0) or np.any(np.diff(curve[:,1])<=0):
        raise ValueError('Tone curve must be strictly monotonic to retain tonal detail.')
    for key in ['global_chroma_scale','red_chroma_scale','yellow_chroma_scale','blue_chroma_scale','green_chroma_scale']:
        if not np.isfinite(op[key]) or not .3<=op[key]<=1.3:
            raise ValueError('Chroma scale out of supported range: '+key)
    if any(op[key]!=0 for key in ['grain','blur','sharpen','halation']):
        raise ValueError('Texture operators are disabled in this deterministic style pilot.')


def roi_weight(shape, row, boxes):
    h, w = shape
    ys = np.arange(row, min(row+128, h))[:, None]/h
    xs = np.arange(w)[None, :]/w
    weight = np.zeros((len(ys), w), dtype=np.float32)
    for x0, y0, x1, y1 in boxes:
        fx, fy = min(.025, (x1-x0)*.15), min(.015, (y1-y0)*.15)
        candidate = smooth(x0, x0+fx, xs)*(1-smooth(x1-fx, x1, xs))*smooth(y0, y0+fy, ys)*(1-smooth(y1-fy, y1, ys))
        weight = np.maximum(weight, candidate)
    return weight


def neutral_anchor(source, context):
    image = Image.fromarray(source.rgb)
    exif = image.getexif(); exif[274] = source.orientation
    image.info['exif'] = exif.tobytes()
    rgb = np.asarray(ImageOps.exif_transpose(image)).astype(np.float32)/255
    h, w = rgb.shape[:2]; mask = np.zeros((h, w), dtype=bool)
    for x0, y0, x1, y1 in context['neutral_anchor_ROIs_display']:
        mask[int(y0*h):int(y1*h), int(x0*w):int(x1*w)] = True
    selected = rgb[mask]
    lab = rgb_to_lab(selected); hsv = rgb_to_hsv(selected)
    valid = (lab[:, 0]>50)&(hsv[:, 1]<.30)
    if valid.sum()<100:
        return np.zeros(2), 0
    return np.median(lab[valid, 1:], axis=0), int(valid.sum())


def quantize(original, candidate, skin, blue, garment, limits):
    before = rgb_to_hsv(original.astype(np.float32)/255)
    safe_high = original.max(axis=-1)<254
    safe_low = original.min(axis=-1)>1
    values = np.rint(np.clip(candidate, 0, 1)*255).astype(np.uint8)
    for _ in range(10):
        values[safe_high] = np.minimum(values[safe_high], 253)
        values[safe_low] = np.maximum(values[safe_low], 2)
        after = rgb_to_hsv(values.astype(np.float32)/255)
        drift = np.abs((after[..., 0]-before[..., 0]+.5)%1-.5)*360
        bad = (skin&(drift>limits[0]+.5))|(blue&(drift>limits[1]+.5))|(garment&(drift>limits[2]+.5))
        if not bad.any():
            return values
        base = original[bad].astype(np.float32)/255
        candidate[bad] = base+.7*(candidate[bad]-base)
        values[bad] = np.rint(np.clip(candidate[bad], 0, 1)*255).astype(np.uint8)
    values[bad] = original[bad]
    return values


def main():
    p = argparse.ArgumentParser(description='CHROMA style model renderer; deterministic, no redraw.')
    p.add_argument('input'); p.add_argument('--output', required=True)
    p.add_argument('--model'); p.add_argument('--faces'); p.add_argument('--skin-scope'); p.add_argument('--context')
    p.add_argument('--plan'); p.add_argument('--strength', type=float, default=1)
    args = p.parse_args()
    output = Path(args.output); plan_file = output.with_suffix('.plan.json'); report_file = output.with_suffix('.report.json')
    originals = {Path(v).resolve() for v in [args.input, args.model, args.faces, args.skin_scope, args.context, args.plan] if v}
    if output.suffix.lower()!='.png' or any(v.resolve() in originals or v.exists() for v in [output, plan_file, report_file]):
        p.error('Use a new PNG output path; inputs and existing files cannot be overwritten.')
    if not 0<=args.strength<=1 or not np.isfinite(args.strength): p.error('Strength must be 0..1.')
    source = load_photo(args.input); source_file_hash = sha256_file(args.input)
    source_hash = pixel_hash(source)
    if args.plan:
        plan = json.loads(Path(args.plan).read_text())
        if plan['source_pixel_sha256']!=source_hash or plan['renderer_sha256']!=sha256_file(__file__):
            p.error('Replay requires the same source and renderer version.')
    else:
        if not all([args.model, args.faces, args.skin_scope, args.context]):
            p.error('Grade requires model, face regions, skin scope and source context.')
        model = json.loads(Path(args.model).read_text()); faces = json.loads(Path(args.faces).read_text())
        context = json.loads(Path(args.context).read_text()); scope = json.loads(Path(args.skin_scope).read_text())
        if faces['source_pixel_sha256']!=source_hash or context['source_pixel_sha256']!=source_hash:
            p.error('Source context/face regions do not match this photo.')
        stats = describe(sample_pixels(source)); ab, count = neutral_anchor(source, context)
        adapt = model['adaptation']
        correction = -np.clip(ab, -np.asarray(adapt['white_balance_max_ab_correction']), np.asarray(adapt['white_balance_max_ab_correction']))*context['white_balance_confidence']
        exposure = float(np.clip((adapt['exposure_target_median_L']-stats['L_percentiles'][3])*adapt['exposure_gain'], -adapt['exposure_limit_L'], adapt['exposure_limit_L']))
        plan = {'schema_version':1, 'engine':'photographic-style-model-v1', 'source_pixel_sha256':source_hash,
                'model':model, 'faces':faces['regions'], 'skin_scope':scope['regions'], 'context':context,
                'white_balance_correction_ab':correction.tolist(), 'neutral_anchor_ab':ab.tolist(),
                'neutral_anchor_pixel_count':count, 'exposure_L':exposure, 'strength':args.strength,
                'renderer_sha256':sha256_file(__file__), 'style_model_sha256':sha256_file(args.model)}
    model = plan['model']
    try: validate_model(model)
    except (ValueError,KeyError,TypeError) as exc: p.error(str(exc))
    op = model['operators']; adapt = model['adaptation']; strength = plan['strength']
    result = np.empty_like(source.rgb); maximum_hue = np.zeros(3); compressed = 0
    limits = [adapt['skin_hue_limit_deg'], adapt['blue_hue_limit_deg'], adapt['red_yellow_hue_limit_deg']]
    for row in range(0, source.rgb.shape[0], 128):
        raw = source.rgb[row:row+128]; rgb = raw.astype(np.float32)/255
        original = rgb_to_lab(rgb); hsv = rgb_to_hsv(rgb); h, s, v = np.moveaxis(hsv.copy(), -1, 0)
        face = roi_weight(source.rgb.shape[:2], row, plan['faces'])
        skin_area = roi_weight(source.rgb.shape[:2], row, plan['skin_scope'])>.1
        skin = skin_area&(h<.15)&(s>.10)&(s<.68)&(v>.20)
        blue = (h>=.52)&(h<=.70)&(s>=.30)&(v>=.23)
        garment = ((h<=.20)|(h>=.95))&(s>=.45)&(v>=.15)&~skin
        saturation_weight = smooth(.18,.45,s)*smooth(.08,.25,v)
        red = (smooth(.92,.99,h)+(1-smooth(.04,.11,h)))*saturation_weight
        red *= ~skin
        yellow = smooth(.07,.10,h)*(1-smooth(.17,.21,h))*saturation_weight*(~skin)
        blue_soft = smooth(.48,.54,h)*(1-smooth(.65,.73,h))*saturation_weight
        green = smooth(.21,.28,h)*(1-smooth(.43,.50,h))*saturation_weight
        red_delta = (op['red_hue_target_deg']/360-h+.5)%1-.5
        hsv[...,0] = (h+red*np.clip(red_delta,-op['red_hue_max_shift_deg']/360,op['red_hue_max_shift_deg']/360)*op['red_hue_attraction']+yellow*op['yellow_hue_rotation_deg']/360+blue_soft*op['blue_hue_rotation_deg']/360)%1
        lab = rgb_to_lab(hsv_to_rgb(hsv))
        lab[...,1:] += np.asarray(plan['white_balance_correction_ab'])
        source_L = original[...,0]; x = np.clip(source_L+plan['exposure_L'],0,100)
        curve = np.asarray(op['tone_curve_L']); lab[...,0] = np.interp(x,curve[:,0],curve[:,1])
        lab[...,0] += red*op['red_lightness_lift_L']+yellow*op['yellow_lightness_lift_L']
        lab[...,0] = np.minimum(lab[...,0],source_L+16)
        # Chroma allocation is an operation, not painting reference RGB onto objects.
        scale = op['global_chroma_scale']*(1+red*(op['red_chroma_scale']-1))*(1+yellow*(op['yellow_chroma_scale']-1))*(1+blue_soft*(op['blue_chroma_scale']-1))*(1+green*(op['green_chroma_scale']-1))
        scale = np.where(skin,1,scale); lab[...,1:] *= scale[...,None]
        original_C = np.linalg.norm(original[...,1:],axis=-1)
        neutral = 1-smooth(8,24,original_C)
        shadow = 1-smooth(28,55,source_L); high = smooth(55,88,source_L)
        lab[...,1:] *= (1-op['neutral_shadow_chroma_reduction']*shadow*neutral)[...,None]
        sky = roi_weight(source.rgb.shape[:2],row,plan['context']['sky_ROIs_stored'])
        tint = (high[...,None]*op['highlight_neutral_ab_bias']+(1-high)[...,None]*op['midtone_neutral_ab_bias'])*neutral[...,None]*(1-sky)[...,None]
        lab[...,1:] += tint
        if skin.any():
            lab[...,0] = np.where(skin,np.clip(lab[...,0],source_L-adapt['skin_L_limit'],source_L+adapt['skin_L_limit']),lab[...,0])
        mapped, count = gamut_map(lab); compressed += count
        local_strength = strength*(1-adapt['face_source_retention']*face)
        mapped = rgb+local_strength[...,None]*(mapped-rgb)
        if strength:
            luma = mapped@np.array([.2126,.7152,.0722]); excess = np.maximum(luma-.95,0)
            shoulder = .95+.027*(-np.expm1(-excess/.027))
            ratio = np.where(luma>.95,shoulder/np.maximum(luma,1e-8),1)
            mapped *= (1+strength*(ratio-1))[...,None]
            quantized = quantize(raw,mapped,skin,blue,garment,limits)
        else:
            quantized = raw.copy()
        if source.alpha is not None: quantized[source.alpha[row:row+128]==0] = raw[source.alpha[row:row+128]==0]
        result[row:row+128] = quantized
        after = rgb_to_hsv(quantized.astype(np.float32)/255)
        drift = np.abs((after[...,0]-h+.5)%1-.5)*360
        for i, mask in enumerate([skin,blue,garment]):
            if mask.any(): maximum_hue[i] = max(maximum_hue[i],float(drift[mask].max()))
    save_photo(Photo(result,source.alpha,source.orientation,{}),output); saved = load_photo(output)
    before, after = clipping(source), clipping(saved)
    checks = {'stored_dimensions_equal':source.rgb.shape==saved.rgb.shape,'orientation_equal':source.orientation==saved.orientation,
              'alpha_equal':(source.alpha is None and saved.alpha is None) or np.array_equal(source.alpha,saved.alpha),
              'input_file_unchanged':sha256_file(args.input)==source_file_hash,
              'new_high_channel_fraction_within_0_5_percent':after['any_channel_high_fraction']-before['any_channel_high_fraction']<=.005,
              'new_near_white_fraction_within_0_1_percent':after['near_white_luma_fraction_sampled']-before['near_white_luma_fraction_sampled']<=.001,
              'skin_hue_within_limit':maximum_hue[0]<=limits[0]+.501,'blue_hue_within_limit':maximum_hue[1]<=limits[1]+.501,
              'red_yellow_hue_within_limit':maximum_hue[2]<=limits[2]+.501}
    checks = {key:bool(value) for key,value in checks.items()}
    report = {'engine':plan['engine'],'status':'technical_checks_passed' if all(checks.values()) else 'needs_review',
              'aesthetic_status':'awaiting_user_review','checks':checks,'style_id':model['id'],'style_axes':model['style_axes'],
              'source':source.metadata,'output':saved.metadata,'source_adaptation':{'exposure_L':plan['exposure_L'],'WB_correction_ab':plan['white_balance_correction_ab']},
              'edit_magnitude':edit_magnitude(source,saved),'maximum_hue_shift_deg':dict(zip(['skin','blue','red_yellow'],maximum_hue.tolist())),
              'clipping':{'before':before,'after':after},'luminance_gradient_correlation_QA_proxy':_gradient_proxy(source,saved),
              'spatial_operations':[],'grain':0,'gamut_compressed_pixels':compressed,
              'reproducibility':{'source_pixel_sha256':source_hash,'output_pixel_sha256':pixel_hash(saved),'renderer_sha256':plan['renderer_sha256']},
              'limits':model['limits']}
    write_json(plan_file,plan); write_json(report_file,report)
    print(json.dumps({'output':str(output),'status':report['status']},ensure_ascii=False),flush=True)
    return 0 if all(checks.values()) else 3


if __name__=='__main__':
    raise SystemExit(main())
