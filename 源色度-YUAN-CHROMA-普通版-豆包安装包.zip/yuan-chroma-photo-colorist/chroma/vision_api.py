"""Optional OpenAI Responses adapter. Core/host-skill path needs no key or SDK."""
import base64
import json
import os
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, build_opener, HTTPRedirectHandler

from .agent import RESOURCES, agent_request, build_request, submit_analysis
from .agent_schema import MODEL_SCHEMA, REVIEW_SCHEMA, validate, validate_model_contract, validate_review_contract
from .io import write_json
from .jobs import _inside, _read, job_status, run_job

ENDPOINT='https://api.openai.com/v1/responses'


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        raise ValueError('API redirect rejected; credentials remain scoped to api.openai.com')


def parse_response(response):
    if not isinstance(response,dict) or response.get('status')!='completed':
        raise ValueError('Vision response incomplete/failed; retained local task, no grading performed')
    parts=[]
    for item in response.get('output',[]):
        for content in item.get('content',[]):
            if content.get('type')=='refusal':
                raise ValueError('Vision model refused analysis; no grading performed')
            if content.get('type')=='output_text':
                parts.append(content.get('text',''))
    if not parts:
        raise ValueError('Vision response contains no structured analysis')
    try:
        result=json.loads(''.join(parts),parse_constant=lambda v: (_ for _ in ()).throw(ValueError('Non-finite JSON value')))
    except (TypeError,json.JSONDecodeError) as exc:
        raise ValueError('Vision response is not valid JSON') from exc
    return result


class ResponsesVision:
    def __init__(self,model,api_key=None):
        if not isinstance(model,str) or not model.strip():
            raise ValueError('Choose a vision model supporting Responses and strict structured outputs via --model')
        key=api_key if api_key is not None else os.environ.get('OPENAI_API_KEY')
        if not key or not key.strip():
            raise ValueError('OPENAI_API_KEY is missing. Configure it locally; never paste it into a chat. Host Agent skill needs no API key.')
        self.model=model;self.key=key

    def analyze(self,instructions,metadata,image,schema,name):
        payload={'model':self.model,'store':False,'max_output_tokens':6000,
            'instructions':instructions,
            'input':[{'role':'user','content':[
                {'type':'input_text','text':json.dumps(metadata,ensure_ascii=False,allow_nan=False)},
                {'type':'input_image','image_url':'data:image/png;base64,'+base64.b64encode(Path(image).read_bytes()).decode(),'detail':'high'}]}],
            'text':{'format':{'type':'json_schema','name':name,'strict':True,'schema':schema}}}
        request=Request(ENDPOINT,data=json.dumps(payload,ensure_ascii=False,allow_nan=False).encode(),
                        headers={'Authorization':'Bearer '+self.key,'Content-Type':'application/json'},method='POST')
        try:
            # No automatic retries: unknown timeouts may already be billable.
            with build_opener(NoRedirect()).open(request,timeout=90) as response:
                raw=response.read(16*1024*1024+1)
            if len(raw)>16*1024*1024:
                raise ValueError('Vision response too large')
            response=json.loads(raw)
        except HTTPError as exc:
            raise ValueError('Vision API HTTP '+str(exc.code)+'. Check model access, billing and structured-output compatibility. No automatic retry.') from None
        except (URLError,TimeoutError) as exc:
            raise ValueError('Vision API unavailable/timed out. Task retained; no automatic retry to avoid duplicate requests.') from None
        value=parse_response(response);validate(value,schema)
        audit={'provider':'openai-responses','model':self.model,'response_id':response.get('id'),
               'usage':response.get('usage'), 'network':'Only 1200px upright preview and stage metadata were submitted; store=false is not a zero-retention guarantee.'}
        return value,audit


def run_api(directory,model,allow_network=False,adapter=None):
    if not allow_network:
        raise ValueError('API mode submits photo previews externally. Use --allow-network only when you choose this mode; host Agent skill is the default.')
    vision=adapter or ResponsesVision(model) # fail before writing anything if key missing
    status=job_status(directory)
    if status['completed']:
        return run_job(directory) # completed jobs resume locally, no API calls
    while True:
        agent_request(directory)
        root,request=build_request(directory)
        token=request['request_sha256']
        style_stage=request['stage']=='reference_style'
        targets=[{'id':'style','preview':request['images'][0]['preview'],'reference_sha256':request['reference_sha256']}] if style_stage else request['sources']
        values=[]
        for item in targets:
            name='style' if style_stage else item['id']
            cached=_inside(root,'api-analysis/'+name+'.json')
            schema=MODEL_SCHEMA if style_stage else REVIEW_SCHEMA
            if cached.exists():
                record=_read(cached)
                if record['request_sha256']!=token or record['model']!=model:
                    raise ValueError('Cached API analysis belongs to another request/model; prepare a new job')
                value=record['analysis'];validate(value,schema)
            else:
                metadata={'reference_sha256':request['reference_sha256']} if style_stage else {
                    'source_pixel_sha256':item['source_pixel_sha256'],'style_model':request['style_model'],
                    'reviewer':'openai-responses:'+model,'stage':'source_adaptation'}
                value,audit=vision.analyze(request['instructions'],metadata,_inside(root,item['preview']),schema,'chroma_'+('style' if style_stage else 'source'))
                validate(value,schema)
                if style_stage:
                    validate_model_contract(value)
                    if value['reference_sha256']!=request['reference_sha256']:
                        raise ValueError('Vision style returned wrong reference identity')
                else:
                    validate_review_contract(value)
                    if value['source_pixel_sha256']!=item['source_pixel_sha256']:
                        raise ValueError('Vision source analysis returned wrong original identity')
                write_json(cached,{'request_sha256':token,'model':model,'analysis':value,'audit':audit})
            values.append(value)
        envelope={'schema_version':1,'request_sha256':token,'style_model':values[0] if style_stage else None,
                  'sources':[] if style_stage else [{'id':item['id'],'review':v} for item,v in zip(targets,values)]}
        result,code=submit_analysis(root,envelope,render=not style_stage)
        if not style_stage:
            return result,code
