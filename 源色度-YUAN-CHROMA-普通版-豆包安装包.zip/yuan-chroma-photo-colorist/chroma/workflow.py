"""Style analysis is a required input to reference-style grading, not RGB matching."""
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np
from .io import load_photo, sha256_file, write_json
from .quality import comparison
from .style_renderer import validate_model

STYLE_AXES = ('tone', 'contrast', 'white_balance', 'color_distribution', 'texture')


def load_style_model(path, reference=None):
    model = json.loads(Path(path).read_text(encoding='utf-8'))
    validate_model(model)
    for key in STYLE_AXES:
        axis = model.get('style_axes', {}).get(key, {})
        if not isinstance(axis, dict):
            raise ValueError('Invalid style axis: '+key)
        confidence = axis.get('confidence')
        if not isinstance(axis.get('description'), str) or not axis['description'].strip():
            raise ValueError('Style analysis requires a description for '+key)
        if not isinstance(confidence, (int, float)) or not np.isfinite(confidence) or not 0<=confidence<=1:
            raise ValueError('Style analysis requires a finite confidence in 0..1 for '+key)
    provenance = model.get('provenance', {})
    if not isinstance(provenance.get('method'), str) or not provenance['method'].strip():
        raise ValueError('Style model must record its analysis method.')
    ref_hash = model.get('reference_sha256', '')
    if not isinstance(ref_hash,str) or len(ref_hash)!=64 or any(c not in '0123456789abcdef' for c in ref_hash):
        raise ValueError('Style model must identify the analyzed reference by SHA-256.')
    if reference and sha256_file(reference)!=ref_hash:
        raise ValueError('Reference differs from the photo analyzed for this style model; analyze the new reference first.')
    def finite(value):
        if isinstance(value,dict): return all(finite(v) for v in value.values())
        if isinstance(value,list): return all(finite(v) for v in value)
        return not isinstance(value,(int,float)) or np.isfinite(value)
    if not finite(model):
        raise ValueError('Style model contains non-finite numbers.')
    return model


def execute_style(args):
    output = Path(args.output)
    if output.suffix.lower()!='.png':
        raise ValueError('Style grading currently requires PNG output.')
    stem = output.with_suffix('')
    paths = [output]+[Path(str(stem)+s) for s in ['.plan.json','.report.json','.compare.png','.workflow.json']]
    inputs = {Path(v).resolve() for v in [args.input, getattr(args,'reference',None),
              getattr(args,'style_model',None),getattr(args,'faces',None),getattr(args,'skin_scope',None),
              getattr(args,'context',None),getattr(args,'plan',None)] if v}
    for path in paths:
        if path.resolve() in inputs or path.exists():
            raise ValueError('Use new output paths; inputs and existing results cannot be overwritten.')
    if args.command=='grade-style':
        # Validate the prior style analysis before reading/adapting the source.
        model = load_style_model(args.style_model,args.reference)
        source_args = ['--model',args.style_model,'--faces',args.faces,'--skin-scope',args.skin_scope,
                       '--context',args.context,'--strength',str(args.strength)]
        model_hash = sha256_file(args.style_model)
    else:
        saved_plan = json.loads(Path(args.plan).read_text(encoding='utf-8'))
        model = saved_plan['model']
        # Saved source-bound plans include the already analyzed style model.
        validate_model(model)
        source_args = ['--plan',args.plan]
        model_hash = saved_plan['style_model_sha256']
    # Preserve the approved renderer byte-for-byte, including its replay hash.
    env = os.environ.copy()
    # Bound UTF-8 JSON and streams even on legacy Windows code pages.
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    package_root = str(Path(__file__).resolve().parent.parent)
    env['PYTHONPATH'] = package_root + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
    run = subprocess.run([sys.executable,'-m','chroma.style_renderer',args.input,
                          '--output',str(output)]+source_args,capture_output=True,text=True,encoding='utf-8',env=env)
    if run.returncode not in (0,3):
        raise ValueError(run.stderr.strip() or run.stdout.strip() or 'Style renderer failed.')
    plan = json.loads(paths[1].read_text(encoding='utf-8'))
    report = json.loads(paths[2].read_text(encoding='utf-8'))
    reference_path = getattr(args,'reference',None)
    reference = load_photo(reference_path) if reference_path else None
    comparison(load_photo(args.input),load_photo(output),paths[3],reference)
    audit = {
        'workflow':'reference_style_first_v1',
        'steps':['analyze_reference_grading_style','validate_style_model','adapt_original_exposure_WB_and_regions',
                 'render_same_coordinate_pixels','technical_QA_and_visual_style_review'],
        'style_model_sha256':model_hash,'reference_sha256':model['reference_sha256'],
        'reference_file_rechecked':bool(reference_path),
        'style_axes':model['style_axes'],'source_pixel_sha256':plan['source_pixel_sha256'],
        'source_adaptation':report['source_adaptation'],
        'mode':'replay_saved_plan' if args.command=='replay-style' else 'new_source_adaptation',
        'analysis_origin':'Agent analysis stored in supplied model; CLI validates and executes, it does not infer style by itself.',
        'aesthetic_status':'awaiting_user_review'
    }
    write_json(paths[4],audit)
    report['workflow']='reference_style_first_v1'
    report['style_analysis_precedes_source_adaptation']=True
    write_json(paths[2],report)
    print(json.dumps({'output':str(output),'quality_status':report['status'],
                      'comparison':str(paths[3]),'workflow':str(paths[4])},ensure_ascii=False))
    return run.returncode
