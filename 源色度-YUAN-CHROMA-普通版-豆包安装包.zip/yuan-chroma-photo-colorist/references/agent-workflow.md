# Agent 接入契约 v1

面向有图像理解与本地执行能力的宿主 Agent。用户不需要编辑 JSON；以下文件由 Agent 和引擎交接。技能只是可复用指令与本地执行器，不是安装后立刻获得视觉能力的独立模型。

## 状态流程

`agent-start` → `reference_style` → `agent-submit` → `source_adaptation` → `agent-submit --render` → `rendered_awaiting_visual_review`。

同参考已分析模型可跳过参考重新拟合，但必须哈希相同，新原图仍须重新分析。风格阶段不能同时提交原图 review；原图阶段 `style_model=null`，禁止改写风格。反馈修订新任务，不能改动已开始执行任务。

`agent-request.json` 提供阶段、实际预览相对路径、参考哈希、原图像素哈希、严格响应 schema、提示词和固定风格。request_sha256 绑定任务、预览、图片、模型、强度、执行器及当前提示词/schema。程序会重新生成预览并与实际工作图核对；EXIF方向不能由 Agent 猜测。相对路径仅限任务目录。

## 响应包

```json
{
  "schema_version": 1,
  "request_sha256": "复制当前 request_sha256",
  "style_model": null,
  "sources": [{"id": "001", "review": {"…": "按当前 response_schema 给完整字段"}}]
}
```

这是形状说明而非可运行素材。风格阶段 style_model 为完整模型且 sources=[]；原图阶段为 null + 全部 source review。每个 source 只能出现一次。范围、布尔/数字类型、曲线单调性、参考身份、原图哈希、WB可信度和区域排序均在本地验证，不能靠提示词替代校验。`chroma/agent_schema.py` 为唯一契约定义，`agent-request.json` 自动导出，不需同步手写schema文件。

提交前在隔离位置验证；提交失败会恢复原 review/model 字节。成功写 `agent-style.receipt.json` / `agent-sources.receipt.json` 保留分析与绑定证据。临时写入 guard 防止渲染读取半次提交；不是多进程调度系统，不要并行操作同一任务。程序中断遗留 guard 或半成品应保留并创建新任务。

## 自动化接口

```sh
python scripts/chroma_agent.py agent-start /path/original.jpg --reference /path/reference.jpg --job-dir /path/new-job
python scripts/chroma_agent.py agent-submit --job-dir /path/new-job --analysis /path/style-response.json
python scripts/chroma_agent.py agent-submit --job-dir /path/new-job --analysis /path/source-response.json --render
python scripts/chroma_agent.py job-status --job-dir /path/new-job
```

宿主需要能查看返回的本地图片，并能写文件、运行上述命令。只有普通文字聊天或没有Python执行/文件读写的GPT，复制SKILL.md不足以完成处理。平台可以用这个接口接自己的模型/工具；核心不强依赖OpenAI。

## 可选 API 适配器

用户主动选择后才执行：先 `agent-start`，再 `agent-api --job-dir … --model 用户配置的视觉模型 --allow-network`。本地环境变量 OPENAI_API_KEY；不把密钥写入照片包或聊天。模型需支持 Responses 图像输入及 strict structured outputs，不硬编码“最新”模型。

先一次参考风格请求，再独立逐图原片请求；已有同参考模型则跳过第一步。发送最长边1200像素的正向PNG预览与必要风格/身份元数据，原分辨率输出始终本地处理。HTTP超时/拒绝/不完整响应时停止，不自动重试计费请求。已完成分析写 api-analysis 可绑定复用，未完成不生成成片。store=false不是零数据留存保证。无 key 不影响宿主技能。

API请求和拒绝处理仅做离线模拟测试，本交付没有真实API调用记录，也没有由独立视觉API新拟合模型的审美验收。相关官方接口依据：[视觉输入](https://developers.openai.com/api/docs/guides/images-vision)、[结构化输出](https://developers.openai.com/api/docs/guides/structured-outputs)。
