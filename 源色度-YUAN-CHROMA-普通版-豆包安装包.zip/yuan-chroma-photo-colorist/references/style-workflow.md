# 参考风格先行工作流契约

固定顺序：参考风格分析 → 风格模型 → 原图适配 → 同坐标像素执行 → 技术与风格双重验收。

## 分析与模型

Agent 用图像理解与摄影后期判断生成模型，CLI 负责校验和执行。`analyze`/`extract-style` 的统计不能自动推导出这个模型。模型不是通过单张 JPEG 还原出来的唯一真实参数，也不能保证任意参考都能准确迁移。

`styles/soft-daylight/style-model.json` 是完整可执行实例。新参考重新分析，不能原样照抄这套实例的控制数值。必需字段：

| 字段 | 含义 |
| --- | --- |
| schema_version / profile_type | `1` / `photographic-grading-style-model` |
| id / name / status | 可追踪模型名称及拟合状态 |
| reference_sha256 | 实际查看的参考文件 SHA-256 |
| style_axes | tone、contrast、white_balance、color_distribution、texture 五轴；各有 description 与 0–1 confidence |
| operators | 影调曲线、色度分配、红黄蓝色相方向、亮部微暖与暗部中性化等操作 |
| adaptation | 原片曝光／白平衡修正限幅、人脸保留权重、皮肤／蓝／红黄色相保护 |
| provenance / limits | 分析方法、拟合数值的性质与不可推断部分 |

tone 的描述应覆盖高光与暗部，color_distribution 覆盖肤色与关键色系，contrast 覆盖整体与局部反差。局部反差与质感判断可记录为“无法分离”而不强行实施。

曲线为 Lab L 0–100 的 [输入,输出] 序列，输入输出严格递增，全部有限且在 0–100。色度比例当前支持 0.3–1.3，禁止非有限数值。grain/blur/sharpen/halation 当前必须为零。其他操作字段与数据单位遵循完整实例；不是 Lightroom 的面板值。新控制范围应结合保护约束和实际成片验证。

`validate-style` 校验模型描述、置信度、来源和关键执行字段，并核对参考文件哈希；`grade-style` 内置同一校验，缺少模型或用统计 profile 替代时拒绝执行。未提供参考文件时可复用已有模型，工作流报告明确标记未重新核对参考文件。

## 原片适配

输入须可被 Pillow 解码，推荐已转成 sRGB 的 PNG；HEIC 先本地解码成工作副本。原片分析保存三个 JSON 文件：

- faces：`source_pixel_sha256` 与 `regions`，矩形为 [x0,y0,x1,y1]，归一化存储坐标。无人物时 regions=[]。
- skin-scope：`regions` 指定脸、颈部、裸露手臂等范围，避免把布料当皮肤；无裸露皮肤时为空。该文件由 Agent 对当前原片分析并与计划一起保存。
- context：`source_pixel_sha256`、`neutral_anchor_ROIs_display`、`white_balance_confidence`、`sky_ROIs_stored` 与分析 reason。中性取样矩形为显示坐标，天空为存储坐标。没有可信中性物体时取样=[]、confidence=0；没有天空或无法可靠圈定时 sky=[]，后者必须在 reason 中说明替代约束与不确定性。

像素哈希由 `chroma.io.pixel_hash(load_photo(path))` 得到，包含归一化像素、Alpha 和方向。可使用本地检测加人工核对确定区域，不自动声称完成人脸分割或保护所有肤色。不同原片的环境适配与矩形不复用。

## 执行与验收

`grade-style` 保存成片、含共享模型和原片适配的 plan、技术 report、并列 compare 和阶段记录 workflow。`replay-style` 使用同源片 plan，已认可执行层字节哈希必须一致。新输出与已有文件都不覆盖。

尺寸、方向、透明度、剪切和色相检查与视觉风格验收分开。新的运行默认 awaiting_user_review；已认可的 20 个具体输出由 evaluation/approved-index.json 索引，原评价记录保存在 evaluation/history/。ΔE76 是修改幅度，梯度相关性是辅助指标，两者均不等于风格准确率。几何不变来自没有空间变换。

如果原图无法承载参考中的物理光照，保留原拍摄事实并说明差异。不能生成太阳、新阴影、物体或纹理来凑出参考效果。零强度无损输出可完全保持归一化像素，非零调色只要求结构和坐标保真。

## 统计实验

低层 `make_plan`/`render` 与 `demo` 保留作预设和历史统计算法测试。用户默认参考风格流程不调用旧全局匹配代替分析。CLI 的旧 `grade --reference`/`--style-profile` 必须显式 `--statistics-only`；统计 profile 与风格操作模型是两种不同格式。
