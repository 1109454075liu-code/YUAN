#!/usr/bin/env python3
"""Run the bundled project from any cwd; never installs dependencies silently."""
import importlib.util
from pathlib import Path
import sys
if sys.version_info<(3,11):
    raise SystemExit("CHROMA needs Python 3.11 or newer.")
root=Path(__file__).resolve().parents[1]
missing=[name for name in ("numpy","PIL") if importlib.util.find_spec(name) is None]
if missing:
    raise SystemExit("CHROMA dependencies missing. Use this Python to install the bundled requirements.txt, then retry.")
sys.path.insert(0,str(root))
from chroma.cli import main
raise SystemExit(main())
