"""Capability probe, not style/aesthetic evaluation or generative editing."""
import argparse
import importlib.util
import json
from pathlib import Path
import platform
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def probe(output):
    if sys.version_info<(3,11):
        return {"status":"needs_python_3_11_plus","host_os":platform.system(),"python":platform.python_version()}
    missing=[m for m in ("numpy","PIL") if importlib.util.find_spec(m) is None]
    if missing:
        return {"status":"needs_dependencies_in_task_sandbox","missing":missing,"host_os":platform.system(),
                "next":"Install pinned requirements in this task sandbox only, then rerun. Do not install on the user's computer."}
    import numpy as np
    import PIL
    if np.__version__!="2.3.5" or PIL.__version__!="12.3.0":
        return {"status":"needs_pinned_dependencies_in_task_sandbox","numpy":np.__version__,"pillow":PIL.__version__,
                "next":"Use NumPy 2.3.5 and Pillow 12.3.0 in an isolated task environment, then rerun."}
    sys.path.insert(0,str(ROOT/"scripts"))
    from windows_self_check import run_check
    from chroma.io import sha256_file
    directory=Path(output).resolve()
    if directory.exists():
        raise ValueError("Use a new probe output directory; existing evidence is never overwritten")
    result=run_check(directory)
    result["status"]="pixel_execution_probe_passed_on_reported_host"
    result["doubao_execution_verified"]=False
    result["verification_note"]="Only a result actually produced by Doubao's task environment verifies Doubao execution; locally generated reports do not."
    result["renderer_sha256"]=sha256_file(ROOT/"chroma/style_renderer.py")
    files={"before":directory/"原图 with spaces.png","after":directory/"测试 job/results/001.png",
        "comparison":directory/"测试 job/results/001.compare.png","plan":directory/"测试 job/results/001.plan.json",
        "technical_report":directory/"测试 job/results/001.report.json"}
    result["artifacts"]={k:{"file":str(p.relative_to(directory)),"sha256":sha256_file(p)} for k,p in files.items()}
    # The outer Agent/human verifies which platform executed this; the Python
    # process never claims platform identity from a supplied name/env flag.
    (directory/"doubao-probe.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return result


if __name__=="__main__":
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,"reconfigure"):stream.reconfigure(encoding="utf-8")
    parser=argparse.ArgumentParser();parser.add_argument("--output",required=True)
    args=parser.parse_args()
    try:
        result=probe(args.output)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        raise SystemExit(0 if result["status"]=="pixel_execution_probe_passed_on_reported_host" else 2)
    except (ValueError,OSError,AssertionError) as exc:
        print("CHROMA probe: "+str(exc),file=sys.stderr)
        raise SystemExit(2)
