"""Local Windows-ready smoke check: geometry, zero-strength and plan replay.

Fixtures are procedural technical images; this is not vision/style validation.
"""
import json
from pathlib import Path
import platform
import sys
import tempfile
from contextlib import redirect_stdout
from io import StringIO

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from chroma.io import load_photo,pixel_hash,sha256_file,write_json
from chroma.agent import agent_start,build_request,submit_analysis
from chroma.cli import main
import numpy as np
from PIL import Image
import PIL


def _run_check(directory=None):
    scratch=Path(tempfile.mkdtemp(prefix='chroma-local-check-')) if directory is None else Path(directory)
    scratch.mkdir(parents=True,exist_ok=True)
    # Unicode and spaces exercise the same argument/JSON pipeline used by Agent.
    source=scratch/'原图 with spaces.png';reference=scratch/'参考 photograph.png'
    rng=np.random.default_rng(6191)
    image=rng.integers(30,220,(48,64,3),dtype=np.uint8)
    exif=Image.Exif();exif[274]=6
    Image.fromarray(image).save(source,exif=exif)
    Image.fromarray(rng.integers(30,220,(48,64,3),dtype=np.uint8)).save(reference)
    original_sha=sha256_file(source)
    model=json.loads((ROOT/'styles/soft-daylight/style-model.json').read_text(encoding='utf-8'))
    model['reference_sha256']=sha256_file(reference)
    model_file=scratch/'回归 model.json';write_json(model_file,model)
    job=scratch/'测试 job'
    agent_start([source],reference,job,model_file)
    _,request=build_request(job)
    review={'schema_version':1,'source_pixel_sha256':pixel_hash(load_photo(job/'inputs/001.png')),
       'coordinate_space':'normalized_upright_display','reviewed':True,'reviewer':'procedural-local-self-check',
       'reason':'程序生成图，仅验证中文路径、UTF-8交接与像素执行，不是视觉或审美验证。',
       'faces_display':[],'skin_display':[],'sky_display':[],'neutral_anchor_ROIs_display':[],
       'white_balance_confidence':0}
    summary,code=submit_analysis(job,{'schema_version':1,'request_sha256':request['request_sha256'],
       'style_model':None,'sources':[{'id':'001','review':review}]},True)
    # Some test patterns may flag clipping/quality: that is retained as evidence;
    # this fixture has safe values and must pass to call setup healthy.
    assert code==0 and summary['completed']==1
    graded=load_photo(job/'results/001.png');src=load_photo(job/'inputs/001.png')
    assert graded.rgb.shape==src.rgb.shape and graded.orientation==src.orientation
    assert pixel_hash(graded)!=pixel_hash(src)
    assert main(['replay-style',str(job/'inputs/001.png'),'--plan',str(job/'results/001.plan.json'),
                 '--output',str(scratch/'replay.png')])==0
    assert pixel_hash(load_photo(scratch/'replay.png'))==pixel_hash(graded)
    assert main(['grade-style',str(job/'inputs/001.png'),'--style-model',str(job/'style-model.json'),
        '--reference',str(reference),'--faces',str(job/'context/001-faces.json'),
        '--skin-scope',str(job/'context/001-skin.json'),'--context',str(job/'context/001-context.json'),
        '--strength','0','--output',str(scratch/'zero.png')])==0
    assert pixel_hash(load_photo(scratch/'zero.png'))==pixel_hash(src)
    assert sha256_file(source)==original_sha
    result={'status':'local_pixel_self_check_passed','host_os':platform.system(),
       'python':platform.python_version(),'architecture':platform.machine(),
       'numpy':np.__version__,'pillow':PIL.__version__,
       'unicode_paths':True,'dimensions_orientation_equal':True,'style_replay_pixel_exact':True,
       'zero_strength_identity':True,'original_unchanged':True,'host_agent_vision_tested':False,
       'scope':'Actual local host only; not a Windows run if host_os is not Windows.'}
    write_json(scratch/'self-check.json',result)
    result['report_directory']=str(scratch)
    return result


def run_check(directory=None):
    with redirect_stdout(StringIO()):
        return _run_check(directory)


if __name__=='__main__':
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8')
    try:
        print(json.dumps(run_check(),ensure_ascii=False,indent=2))
    except (OSError,ValueError,AssertionError,KeyError) as exc:
        print('CHROMA self-check failed: '+str(exc),file=sys.stderr)
        raise SystemExit(2)
